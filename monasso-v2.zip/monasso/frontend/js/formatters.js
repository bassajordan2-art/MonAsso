window.MonAssoFormatters = (function () {
  'use strict';

  const THEMES = {
    emeraude: {
      id: 'emeraude',
      label: 'Émeraude',
      accent: '#0F6B4E',
      accentStrong: '#094D37',
      accentSoft: '#E6F4EE',
      accentRing: 'rgba(15, 107, 78, 0.22)',
    },
    lagune: {
      id: 'lagune',
      label: 'Lagune',
      accent: '#0B5CAD',
      accentStrong: '#07407C',
      accentSoft: '#E8F2FC',
      accentRing: 'rgba(11, 92, 173, 0.22)',
    },
    terracotta: {
      id: 'terracotta',
      label: 'Terracotta',
      accent: '#B84A27',
      accentStrong: '#8E3418',
      accentSoft: '#FBECE6',
      accentRing: 'rgba(184, 74, 39, 0.22)',
    },
    or: {
      id: 'or',
      label: 'Or & Cacao',
      accent: '#9E6308',
      accentStrong: '#774904',
      accentSoft: '#FBF2E0',
      accentRing: 'rgba(158, 99, 8, 0.22)',
    },
    prune: {
      id: 'prune',
      label: 'Prune Royale',
      accent: '#6B3FA0',
      accentStrong: '#4F2C79',
      accentSoft: '#F2ECFA',
      accentRing: 'rgba(107, 63, 160, 0.22)',
    },
    ardoise: {
      id: 'ardoise',
      label: 'Ardoise',
      accent: '#2E4756',
      accentStrong: '#1F313C',
      accentSoft: '#EBF0F3',
      accentRing: 'rgba(46, 71, 86, 0.22)',
    },
  };

  const OPERATORS = [
    {
      id: 'Wave',
      name: 'Wave',
      short: 'W',
      color: '#0A95D6',
      soft: '#E6F6FD',
      ink: '#FFFFFF',
      hint: 'Validation instantanée sur application Wave',
    },
    {
      id: 'Orange Money',
      name: 'Orange Money',
      short: 'OM',
      color: '#FF7900',
      soft: '#FFF1E5',
      ink: '#FFFFFF',
      hint: 'Confirmation mobile simulée (#144#)',
    },
    {
      id: 'MTN MoMo',
      name: 'MTN MoMo',
      short: 'MTN',
      color: '#FFCC00',
      soft: '#FFF9DB',
      ink: '#1A1A1A',
      hint: 'Validation Mobile Money (*133#)',
    },
    {
      id: 'Moov Money',
      name: 'Moov Money',
      short: 'MOOV',
      color: '#005BAC',
      soft: '#E8F1FA',
      ink: '#FFFFFF',
      hint: 'Validation Moov Africa (*155#)',
    },
  ];

  const MONTHS_FR = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
  ];

  function formatMoney(amount, devise = 'FCFA') {
    if (amount === null || amount === undefined || Number.isNaN(Number(amount))) {
      return 'Montant libre';
    }
    const num = Number(amount);
    if (devise === 'FCFA') {
      const formatted = new Intl.NumberFormat('fr-FR', {
        maximumFractionDigits: 0,
      }).format(Math.round(num));
      return `${formatted} FCFA`;
    }
    if (devise === 'EUR') {
      return new Intl.NumberFormat('fr-FR', {
        style: 'currency',
        currency: 'EUR',
      }).format(num);
    }
    if (devise === 'USD') {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
      }).format(num);
    }
    if (devise === 'CAD') {
      return `${new Intl.NumberFormat('fr-CA', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(num)} $ CA`;
    }
    return `${num} ${devise}`;
  }

  function formatDateTime(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  }

  function formatDateFull(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    return new Intl.DateTimeFormat('fr-FR', {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  }

  function formatDateOnly(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }).format(d);
  }

  function getCurrentPeriodLabel(rythme = 'Mensuel', offset = 0) {
    const now = new Date();
    if (rythme === 'Hebdomadaire') {
      const target = new Date(now.getTime() + offset * 7 * 86400000);
      const startOfYear = new Date(target.getFullYear(), 0, 1);
      const week = Math.ceil(((target - startOfYear) / 86400000 + startOfYear.getDay() + 1) / 7);
      return `Semaine ${week} (${target.getFullYear()})`;
    }
    if (rythme === 'Bimensuel') {
      const baseMonth = now.getMonth() + Math.floor(offset / 2);
      const dt = new Date(now.getFullYear(), baseMonth, 1);
      const quinzaine = (now.getDate() <= 15 ? 0 : 1) + (offset % 2);
      const qLabel = Math.abs(quinzaine) % 2 === 0 ? '1re quinzaine' : '2e quinzaine';
      return `${qLabel} ${MONTHS_FR[dt.getMonth()]} ${dt.getFullYear()}`;
    }
    if (rythme === 'Trimestriel') {
      const currentQ = Math.floor(now.getMonth() / 3);
      const totalQ = now.getFullYear() * 4 + currentQ + offset;
      const year = Math.floor(totalQ / 4);
      const q = ((totalQ % 4) + 4) % 4;
      return `Trimestre ${q + 1} ${year}`;
    }
    if (rythme === 'Annuel') {
      return `Année ${now.getFullYear() + offset}`;
    }
    if (rythme === 'Ponctuel') {
      return offset === 0 ? 'Cotisation en cours' : `Cotisation #${offset + 4}`;
    }
    // Mensuel par défaut
    const dt = new Date(now.getFullYear(), now.getMonth() + offset, 1);
    return `${MONTHS_FR[dt.getMonth()]} ${dt.getFullYear()}`;
  }

  function buildPaymentCalendar(association, cotisations) {
    const rythme = association ? association.rythme : 'Mensuel';
    const offsets = [-2, -1, 0, 1, 2, 3];
    const items = offsets.map((offset) => {
      const label = getCurrentPeriodLabel(rythme, offset);
      const matched = (cotisations || []).find((c) => {
        if (c.statut !== 'Validée') return false;
        if (c.periode && c.periode.toLowerCase() === label.toLowerCase()) return true;
        if (rythme === 'Mensuel' && c.date) {
          const d = new Date(c.date);
          const dateLabel = `${MONTHS_FR[d.getMonth()]} ${d.getFullYear()}`;
          return dateLabel.toLowerCase() === label.toLowerCase();
        }
        return false;
      });
      return {
        label,
        isCurrent: offset === 0,
        isFuture: offset > 0,
        paid: Boolean(matched),
        receipt: matched || null,
      };
    });
    return items;
  }

  function getOperatorMeta(opName) {
    return OPERATORS.find((o) => o.id === opName) || OPERATORS[0];
  }

  function applyTheme(colorId) {
    const theme = THEMES[colorId] || THEMES.emeraude;
    const root = document.documentElement;
    root.style.setProperty('--accent', theme.accent);
    root.style.setProperty('--accent-strong', theme.accentStrong);
    root.style.setProperty('--accent-soft', theme.accentSoft);
    root.style.setProperty('--accent-ring', theme.accentRing);
    return theme;
  }

  function isBureauRole(role) {
    return ['Administrateur', 'Président', 'Secrétaire', 'Trésorier', 'Bureau'].includes(role);
  }

  return {
    THEMES,
    OPERATORS,
    formatMoney,
    formatDateTime,
    formatDateFull,
    formatDateOnly,
    getCurrentPeriodLabel,
    buildPaymentCalendar,
    getOperatorMeta,
    applyTheme,
    isBureauRole,
  };
})();
