window.MonAssoApi = (function () {
  'use strict';

  const TOKEN_KEY = 'monasso_session_token';
  const OFFLINE_DB_KEY = 'monasso_offline_demo_db_v1';
  const IS_FILE_MODE = window.location.protocol === 'file:';

  function getToken() {
    return sessionStorage.getItem(TOKEN_KEY);
  }

  function setToken(token) {
    if (token) {
      sessionStorage.setItem(TOKEN_KEY, token);
    } else {
      sessionStorage.removeItem(TOKEN_KEY);
    }
  }

  function loadOfflineDb() {
    const raw = localStorage.getItem(OFFLINE_DB_KEY);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {
        // réinitialise si corrompu
      }
    }
    const now = new Date();
    const dPlus = (days, h) => {
      const d = new Date(now.getTime() + days * 86400000);
      d.setHours(h, 0, 0, 0);
      return d.toISOString();
    };
    const initial = {
      nextAssocId: 2,
      nextMemberId: 7,
      nextEventId: 4,
      associations: [
        {
          id_assoc: 1,
          nom: 'Amicale Fraternité Cocody',
          montant: 10000,
          rythme: 'Mensuel',
          devise: 'FCFA',
          code: 'DEMO',
          pinBureau: '2026',
          created_at: now.toISOString(),
        },
      ],
      membres: [
        { id_membre: 1, nom: 'Kouadio Konan', role: 'Administrateur', couleur: 'emeraude', id_assoc: 1, created_at: now.toISOString() },
        { id_membre: 2, nom: 'Mariam Touré', role: 'Trésorier', couleur: 'lagune', id_assoc: 1, created_at: now.toISOString() },
        { id_membre: 3, nom: 'Fatoumata Diallo', role: 'Secrétaire', couleur: 'prune', id_assoc: 1, created_at: now.toISOString() },
        { id_membre: 4, nom: 'Aïcha Bamba', role: 'Membre', couleur: 'emeraude', id_assoc: 1, created_at: now.toISOString() },
        { id_membre: 5, nom: 'Jean-Luc Koffi', role: 'Membre', couleur: 'terracotta', id_assoc: 1, created_at: now.toISOString() },
        { id_membre: 6, nom: 'Moussa Coulibaly', role: 'Membre', couleur: 'or', id_assoc: 1, created_at: now.toISOString() },
      ],
      cotisations: [
        { num_recu: 'REC-20261005-204819', date: dPlus(-30, 9), montant: 10000, operateur: 'Orange Money', statut: 'Validée', periode: 'Octobre 2026', id_membre: 4 },
        { num_recu: 'REC-20261108-452018', date: dPlus(-18, 11), montant: 10000, operateur: 'Wave', statut: 'Validée', periode: 'Novembre 2026', id_membre: 1 },
        { num_recu: 'REC-20261109-590133', date: dPlus(-17, 15), montant: 10000, operateur: 'Orange Money', statut: 'Validée', periode: 'Novembre 2026', id_membre: 2 },
        { num_recu: 'REC-20261112-674329', date: dPlus(-14, 19), montant: 10000, operateur: 'Wave', statut: 'Validée', periode: 'Novembre 2026', id_membre: 3 },
      ],
      evenements: [
        { id_event: 1, titre: 'Réunion mensuelle de suivi des cotisations', type: 'Réunion', date: dPlus(4, 18), description: 'Point sur la caisse du mois et questions diverses.', id_assoc: 1 },
        { id_event: 2, titre: 'Journée d’entraide et remise de fonds', type: 'Activité', date: dPlus(12, 10), description: 'Rencontre conviviale des membres.', id_assoc: 1 },
        { id_event: 3, titre: 'Assemblée générale annuelle 2026-2027', type: 'Assemblée générale', date: dPlus(24, 9), description: 'Bilan financier et perspectives.', id_assoc: 1 },
      ],
      participer: [
        { id_membre: 1, id_event: 1, reponse: 'Je participe' },
        { id_membre: 2, id_event: 1, reponse: 'Je participe' },
        { id_membre: 4, id_event: 3, reponse: 'Je participe' },
      ],
    };
    localStorage.setItem(OFFLINE_DB_KEY, JSON.stringify(initial));
    return initial;
  }

  function saveOfflineDb(db) {
    localStorage.setItem(OFFLINE_DB_KEY, JSON.stringify(db));
    if ('BroadcastChannel' in window) {
      const ch = new BroadcastChannel('monasso_offline_sync');
      ch.postMessage({ type: 'sync' });
      ch.close();
    }
  }

  function isBureauRole(role) {
    return ['Administrateur', 'Président', 'Secrétaire', 'Trésorier', 'Bureau'].includes(role);
  }

  function sortAssociationMembers(members) {
    const rank = (role) => {
      if (role === 'Administrateur') return 0;
      if (isBureauRole(role)) return 1;
      return 2;
    };
    return [...members].sort((a, b) => {
      const diff = rank(a.role) - rank(b.role);
      if (diff !== 0) return diff;
      return String(a.nom || '').localeCompare(String(b.nom || ''), 'fr');
    });
  }

  function offlineRequest(method, path, body) {
    const db = loadOfflineDb();
    const token = getToken();
    const currentMember = token ? db.membres.find((m) => `offline-${m.id_membre}` === token) : null;
    const currentAssoc = currentMember ? db.associations.find((a) => a.id_assoc === currentMember.id_assoc) : null;

    if (method === 'POST' && path === '/api/associations') {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
      let code = '';
      for (let i = 0; i < 6; i += 1) code += chars[Math.floor(Math.random() * chars.length)];
      const assoc = {
        id_assoc: db.nextAssocId++,
        nom: body.nom.trim(),
        montant: body.montant ? Number(body.montant) : null,
        rythme: body.rythme,
        devise: body.devise,
        code,
        pinBureau: body.pinBureau || '1234',
        created_at: new Date().toISOString(),
      };
      db.associations.push(assoc);
      const membre = {
        id_membre: db.nextMemberId++,
        nom: body.fondateurNom.trim(),
        role: 'Administrateur',
        couleur: 'emeraude',
        id_assoc: assoc.id_assoc,
        created_at: new Date().toISOString(),
      };
      db.membres.push(membre);
      saveOfflineDb(db);
      const newToken = `offline-${membre.id_membre}`;
      setToken(newToken);
      return Promise.resolve({
        token: newToken,
        association: assoc,
        membre,
        pinBureau: assoc.pinBureau,
        permissions: { isBureau: true, isAdmin: true },
      });
    }

    if (method === 'POST' && path === '/api/associations/join') {
      const code = String(body.code || '').trim().toUpperCase();
      const assoc = db.associations.find((a) => a.code === code);
      if (!assoc) {
        return Promise.reject(new Error('Code d’invitation introuvable.'));
      }
      const nom = code === 'DEMO' && (!body.nom || !body.nom.trim()) ? 'Aïcha Bamba' : String(body.nom || '').trim();
      if (!nom || nom.length < 2) {
        return Promise.reject(new Error('Veuillez saisir votre nom complet.'));
      }
      let membre = db.membres.find((m) => m.id_assoc === assoc.id_assoc && m.nom.toLowerCase() === nom.toLowerCase());
      let joinedNew = false;
      if (membre) {
        if (isBureauRole(membre.role)) {
          if (!body.pinBureau || String(body.pinBureau).trim() !== assoc.pinBureau) {
            const err = new Error('Code PIN Bureau requis ou incorrect.');
            err.requiresPin = true;
            return Promise.reject(err);
          }
        }
      } else {
        membre = {
          id_membre: db.nextMemberId++,
          nom,
          role: 'Membre',
          couleur: 'emeraude',
          id_assoc: assoc.id_assoc,
          created_at: new Date().toISOString(),
        };
        db.membres.push(membre);
        joinedNew = true;
      }
      saveOfflineDb(db);
      const newToken = `offline-${membre.id_membre}`;
      setToken(newToken);
      return Promise.resolve({
        token: newToken,
        association: assoc,
        membre,
        joinedNew,
        permissions: { isBureau: isBureauRole(membre.role), isAdmin: membre.role === 'Administrateur' },
      });
    }

    if (method === 'POST' && path === '/api/associations/recover-code') {
      const nom = String(body.nom || '').trim();
      if (nom.length < 2) {
        return Promise.reject(new Error('Veuillez saisir votre nom complet (entre 2 et 80 caractères).'));
      }
      const assocFilter = String(body.assocNom || '').trim().toLowerCase();
      const matches = db.membres
        .filter((m) => m.nom.trim().toLowerCase() === nom.toLowerCase())
        .map((m) => {
          const assoc = db.associations.find((a) => a.id_assoc === m.id_assoc);
          if (!assoc) return null;
          if (assocFilter && !assoc.nom.toLowerCase().includes(assocFilter)) return null;
          return {
            id_assoc: assoc.id_assoc,
            nom_association: assoc.nom,
            rythme: assoc.rythme,
            devise: assoc.devise,
            code: assoc.code,
            membre_nom: m.nom,
            role: m.role,
            requiresPin: isBureauRole(m.role),
          };
        })
        .filter(Boolean);

      if (matches.length === 0) {
        return Promise.reject(
          new Error('Aucune association trouvée pour ce nom. Vérifiez l’orthographe exacte utilisée lors de votre inscription.')
        );
      }
      return Promise.resolve({ matches });
    }

    if (!currentMember || !currentAssoc) {
      return Promise.reject(new Error('Session expirée.'));
    }

    if (method === 'GET' && path === '/api/workspace') {
      const isBureau = isBureauRole(currentMember.role);
      const sortedMembers = sortAssociationMembers(
        db.membres.filter((m) => m.id_assoc === currentAssoc.id_assoc)
      );
      const membres = sortedMembers.map((m) => ({
        id_membre: m.id_membre,
        nom: m.nom,
        role: m.role,
        couleur: m.couleur,
        created_at: m.created_at,
      }));

      const myCotisations = db.cotisations
        .filter((c) => c.id_membre === currentMember.id_membre)
        .sort((a, b) => b.date.localeCompare(a.date));

      const evenements = db.evenements
        .filter((e) => e.id_assoc === currentAssoc.id_assoc)
        .sort((a, b) => a.date.localeCompare(b.date))
        .map((ev) => {
          const parts = db.participer
            .filter((p) => p.id_event === ev.id_event)
            .map((p) => {
              const m = db.membres.find((mm) => mm.id_membre === p.id_membre);
              return { id_membre: p.id_membre, nom: m ? m.nom : 'Membre', role: m ? m.role : 'Membre', reponse: p.reponse };
            });
          const mine = parts.find((p) => p.id_membre === currentMember.id_membre);
          return {
            ...ev,
            participantsCount: parts.filter((p) => p.reponse === 'Je participe').length,
            totalResponses: parts.length,
            myResponse: mine ? mine.reponse : null,
            participants: isBureau ? parts : undefined,
          };
        });

      let registry = null;
      if (isBureau) {
        const assocMembers = sortedMembers;
        const memberIds = new Set(assocMembers.map((m) => m.id_membre));
        const allCot = db.cotisations
          .filter((c) => memberIds.has(c.id_membre))
          .sort((a, b) => b.date.localeCompare(a.date))
          .map((c) => {
            const m = assocMembers.find((mm) => mm.id_membre === c.id_membre);
            return { ...c, membre_nom: m ? m.nom : 'Membre', membre_role: m ? m.role : 'Membre' };
          });
        const membersWithStats = assocMembers.map((m) => {
          const mc = allCot.filter((c) => c.id_membre === m.id_membre);
          return {
            ...m,
            total_verse: mc.reduce((s, x) => s + Number(x.montant), 0),
            nb_cotisations: mc.length,
            dernier_paiement: mc[0] ? mc[0].date : null,
          };
        });
        const byOperator = {};
        let totalCaisse = 0;
        allCot.forEach((c) => {
          totalCaisse += Number(c.montant);
          byOperator[c.operateur] = (byOperator[c.operateur] || 0) + Number(c.montant);
        });
        registry = {
          membres: membersWithStats,
          cotisations: allCot,
          stats: {
            totalCaisse,
            totalTransactions: allCot.length,
            payingMembersCount: membersWithStats.filter((m) => m.nb_cotisations > 0).length,
            totalMembersCount: membersWithStats.length,
            byOperator,
          },
        };
      }

      return Promise.resolve({
        association: currentAssoc,
        membre: currentMember,
        permissions: { isBureau, isAdmin: currentMember.role === 'Administrateur' },
        membres,
        myCotisations,
        evenements,
        registry,
      });
    }

    if (method === 'POST' && path === '/api/cotisations') {
      const numRecu = `REC-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100000 + Math.random() * 899999)}`;
      const cotisation = {
        num_recu: numRecu,
        date: new Date().toISOString(),
        montant: Number(body.montant),
        operateur: body.operateur,
        statut: 'Validée',
        periode: body.periode || null,
        id_membre: currentMember.id_membre,
      };
      db.cotisations.push(cotisation);
      saveOfflineDb(db);
      return Promise.resolve({ cotisation, membre: currentMember, association: currentAssoc });
    }

    if (method === 'PATCH' && path === '/api/membres/me/couleur') {
      currentMember.couleur = body.couleur;
      saveOfflineDb(db);
      return Promise.resolve({ membre: currentMember });
    }

    if (method === 'POST' && path === '/api/evenements') {
      if (!isBureauRole(currentMember.role)) {
        return Promise.reject(new Error('Action réservée au bureau.'));
      }
      const ev = {
        id_event: db.nextEventId++,
        titre: body.titre.trim(),
        type: body.type,
        date: new Date(body.date).toISOString(),
        description: body.description || '',
        id_assoc: currentAssoc.id_assoc,
      };
      db.evenements.push(ev);
      saveOfflineDb(db);
      return Promise.resolve({ evenement: ev });
    }

    const partMatch = path.match(/^\/api\/evenements\/(\d+)\/participer$/);
    if (method === 'POST' && partMatch) {
      const idEvent = Number(partMatch[1]);
      const idx = db.participer.findIndex((p) => p.id_membre === currentMember.id_membre && p.id_event === idEvent);
      if (idx >= 0) {
        db.participer[idx].reponse = body.reponse;
      } else {
        db.participer.push({ id_membre: currentMember.id_membre, id_event: idEvent, reponse: body.reponse });
      }
      saveOfflineDb(db);
      return Promise.resolve({ id_event: idEvent, reponse: body.reponse });
    }

    const roleMatch = path.match(/^\/api\/membres\/(\d+)\/role$/);
    if (method === 'PATCH' && roleMatch) {
      const targetId = Number(roleMatch[1]);
      const target = db.membres.find((m) => m.id_membre === targetId && m.id_assoc === currentAssoc.id_assoc);
      if (!target) return Promise.reject(new Error('Membre introuvable.'));
      target.role = body.role;
      saveOfflineDb(db);
      return Promise.resolve({ membre: target });
    }

    if (method === 'POST' && path === '/api/auth/logout') {
      setToken(null);
      return Promise.resolve({ ok: true });
    }

    return Promise.resolve({ ok: true });
  }

  async function request(method, path, body) {
    if (IS_FILE_MODE) {
      return offlineRequest(method, path, body);
    }

    const headers = { Accept: 'application/json' };
    const token = getToken();
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }
    const opts = { method, headers };
    if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }

    const res = await fetch(path, opts);
    let data = {};
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) {
      data = await res.json();
    }
    if (!res.ok) {
      const err = new Error(data.error || `Erreur serveur (${res.status})`);
      err.status = res.status;
      err.requiresPin = Boolean(data.requiresPin);
      throw err;
    }
    return data;
  }

  async function openRealtimeStream(onSync, onStatusChange) {
    if (IS_FILE_MODE) {
      const channel = 'BroadcastChannel' in window ? new BroadcastChannel('monasso_offline_sync') : null;
      if (channel) {
        channel.onmessage = () => onSync('local');
      }
      onStatusChange('offline');
      return () => {
        if (channel) channel.close();
      };
    }

    let closed = false;
    let source = null;

    async function connect() {
      if (closed || !getToken()) return;
      try {
        const { ticket } = await request('POST', '/api/auth/stream-ticket');
        if (closed) return;
        source = new EventSource(`/api/stream?ticket=${encodeURIComponent(ticket)}`);
        source.addEventListener('connected', () => onStatusChange('live'));
        source.addEventListener('sync', (ev) => {
          try {
            const payload = JSON.parse(ev.data);
            onSync(payload.reason);
          } catch {
            onSync('update');
          }
        });
        source.onerror = () => {
          onStatusChange('reconnecting');
          if (source) {
            source.close();
            source = null;
          }
          if (!closed) {
            setTimeout(connect, 4000);
          }
        };
      } catch {
        onStatusChange('reconnecting');
      }
    }

    connect();

    return () => {
      closed = true;
      if (source) {
        source.close();
        source = null;
      }
    };
  }

  return {
    IS_FILE_MODE,
    getToken,
    setToken,
    createAssociation: (payload) => request('POST', '/api/associations', payload).then((res) => {
      setToken(res.token);
      return res;
    }),
    joinAssociation: (payload) => request('POST', '/api/associations/join', payload).then((res) => {
      setToken(res.token);
      return res;
    }),
    recoverCode: (payload) => request('POST', '/api/associations/recover-code', payload),
    logout: async () => {
      try {
        await request('POST', '/api/auth/logout');
      } catch {
        // ignore network error on logout
      }
      setToken(null);
    },
    getWorkspace: () => request('GET', '/api/workspace'),
    payCotisation: (payload) => request('POST', '/api/cotisations', payload),
    updateColor: (couleur) => request('PATCH', '/api/membres/me/couleur', { couleur }),
    createEvent: (payload) => request('POST', '/api/evenements', payload),
    respondEvent: (idEvent, reponse) => request('POST', `/api/evenements/${idEvent}/participer`, { reponse }),
    updateMemberRole: (idMembre, role) => request('PATCH', `/api/membres/${idMembre}/role`, { role }),
    exportRegistryCsv: async () => {
      if (IS_FILE_MODE) {
        const data = await offlineRequest('GET', '/api/workspace');
        const rows = (data.registry && data.registry.cotisations) || [];
        const lines = ['"N° Reçu";"Date";"Membre";"Opérateur";"Période";"Montant";"Devise";"Statut"'];
        rows.forEach((r) => {
          lines.push(`"${r.num_recu}";"${r.date}";"${r.membre_nom}";"${r.operateur}";"${r.periode || ''}";"${r.montant}";"${data.association.devise}";"${r.statut}"`);
        });
        return {
          blob: new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' }),
          filename: `registre-${data.association.code.toLowerCase()}.csv`,
        };
      }
      const res = await fetch('/api/registry/export', {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      if (!res.ok) throw new Error('Impossible d’exporter le registre.');
      const blob = await res.blob();
      const disp = res.headers.get('content-disposition') || '';
      const m = disp.match(/filename="([^"]+)"/);
      return { blob, filename: m ? m[1] : 'registre-monasso.csv' };
    },
    openRealtimeStream,
  };
})();
