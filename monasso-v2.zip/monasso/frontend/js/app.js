(function () {
  'use strict';

  const F = window.MonAssoFormatters;
  const Api = window.MonAssoApi;
  const Ui = window.MonAssoUi;

  const state = {
    workspace: null,
    activeWsTab: 'dashboard',
    selectedOperator: 'Wave',
    pendingPayment: null,
    activeReceipt: null,
    activeReceiptMember: '',
    closeStream: null,
    syncPollTimer: null,
  };

  function $(id) {
    return document.getElementById(id);
  }

  function showError(boxId, message) {
    const box = $(boxId);
    if (!box) return;
    if (!message) {
      box.textContent = '';
      box.classList.add('is-hidden');
    } else {
      box.textContent = message;
      box.classList.remove('is-hidden');
    }
  }

  function switchAuthTab(tabName) {
    document.querySelectorAll('.auth-tab').forEach((btn) => {
      const active = btn.dataset.authTab === tabName;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    $('join-form').classList.toggle('is-hidden', tabName !== 'join');
    $('create-form').classList.toggle('is-hidden', tabName !== 'create');
    $('demo-panel').classList.toggle('is-hidden', tabName !== 'demo');
  }

  function switchMeriseTab(tabName) {
    document.querySelectorAll('.merise-tab').forEach((btn) => {
      btn.classList.toggle('is-active', btn.dataset.meriseTab === tabName);
    });
    ['problematique', 'donnees', 'securite'].forEach((name) => {
      $(`merise-panel-${name}`).classList.toggle('is-hidden', name !== tabName);
    });
  }

  function switchWorkspaceTab(tabName) {
    const isBureau = Boolean(state.workspace && state.workspace.permissions && state.workspace.permissions.isBureau);
    const target = tabName === 'bureau' && !isBureau ? 'dashboard' : tabName;
    state.activeWsTab = target;

    document.querySelectorAll('[data-ws-tab]').forEach((btn) => {
      btn.classList.toggle('is-active', btn.dataset.wsTab === target);
    });

    ['dashboard', 'cotiser', 'agenda', 'membres', 'bureau', 'profil'].forEach((name) => {
      const panel = $(`tab-${name}`);
      if (panel) panel.classList.toggle('is-hidden', name !== target);
    });
  }

  function openModal(id) {
    $(id).classList.remove('is-hidden');
  }

  function closeModal(id) {
    $(id).classList.add('is-hidden');
  }

  function buildInviteText(association) {
    const montantTxt = association.montant
      ? F.formatMoney(association.montant, association.devise)
      : 'montant libre';
    const urlHint = window.location.protocol === 'file:' ? '' : ` sur ${window.location.origin}`;
    return `Bonjour ! Rejoignez l’association "${association.nom}" (${montantTxt} / ${association.rythme}) sur MonAsso${urlHint} avec le code d’invitation : ${association.code}`;
  }

  async function copyCodeString(code) {
    try {
      await navigator.clipboard.writeText(code);
      Ui.showToast(`Code ${code} copié !`, 'success');
    } catch {
      Ui.showToast(`Code de votre association : ${code}`, 'info');
    }
  }

  async function copyInvite(association) {
    const text = buildInviteText(association);
    try {
      await navigator.clipboard.writeText(association.code);
      Ui.showToast(`Code ${association.code} copié !`, 'success');
    } catch {
      Ui.showToast(`Code : ${association.code} — ${text}`, 'info');
    }
  }

  function shareOnWhatsApp(association) {
    const text = encodeURIComponent(buildInviteText(association));
    window.open(`https://wa.me/?text=${text}`, '_blank', 'noopener,noreferrer');
  }

  function setSyncBadge(status) {
    const badge = $('ws-sync-badge');
    if (!badge) return;
    badge.classList.remove('is-live', 'is-warn');
    if (status === 'live') {
      badge.textContent = '● Temps réel';
      badge.classList.add('is-live');
    } else if (status === 'offline') {
      badge.textContent = '● Mode local';
      badge.classList.add('is-warn');
    } else {
      badge.textContent = '● Synchronisation…';
      badge.classList.add('is-warn');
    }
  }

  function renderFilteredMembersDirectory() {
    const ws = state.workspace;
    if (!ws) return;
    const allMembers = ws.membres || [];
    const query = ($('membres-search').value || '').trim().toLowerCase();
    const roleFilter = $('membres-filter-role').value;

    const filtered = allMembers.filter((m) => {
      if (roleFilter === 'bureau' && !F.isBureauRole(m.role)) return false;
      if (roleFilter === 'membre' && F.isBureauRole(m.role)) return false;
      if (query) {
        const matchName = (m.nom || '').toLowerCase().includes(query);
        const matchRole = (m.role || '').toLowerCase().includes(query);
        return matchName || matchRole;
      }
      return true;
    });

    Ui.renderMembersDirectory($('membres-directory-grid'), filtered, ws.membre.id_membre);
  }

  function renderWorkspace() {
    const ws = state.workspace;
    if (!ws) return;

    const { association, membre, permissions, myCotisations, evenements, registry } = ws;
    const membres = ws.membres || [];
    F.applyTheme(membre.couleur);

    $('ws-assoc-name').textContent = association.nom;
    const montantRef = association.montant ? F.formatMoney(association.montant, association.devise) : 'Montant libre';
    $('ws-assoc-meta').textContent = `${association.rythme} • ${association.devise} (${montantRef})`;
    $('ws-assoc-code').textContent = association.code;
    $('sidebar-code').textContent = association.code;
    $('ws-member-name').textContent = membre.nom;
    $('ws-member-role').textContent = membre.role;
    $('ws-member-avatar').textContent = (membre.nom || 'M').trim().charAt(0).toUpperCase();

    $('nav-bureau-desktop').classList.toggle('is-hidden', !permissions.isBureau);
    $('nav-bureau-mobile').classList.toggle('is-hidden', !permissions.isBureau);
    $('agenda-new-event-btn').classList.toggle('is-hidden', !permissions.isBureau);

    $('dash-role-badge').textContent = permissions.isBureau
      ? `${membre.role} • Accès complet au registre`
      : `Espace personnel • ${membre.role}`;
    $('dash-greeting').textContent = `Bonjour, ${membre.nom}`;
    const totalPaid = (myCotisations || []).reduce((sum, c) => sum + Number(c.montant), 0);
    $('dash-total-paid').textContent = F.formatMoney(totalPaid, association.devise);
    $('dash-cotisation-target').textContent = association.montant
      ? `Référence : ${F.formatMoney(association.montant, association.devise)} (${association.rythme})`
      : `Cotisation libre (${association.rythme})`;
    $('dash-receipt-count').textContent = String((myCotisations || []).length);
    $('dash-last-receipt').textContent = myCotisations && myCotisations[0]
      ? `Dernier : ${F.formatDateOnly(myCotisations[0].date)} (${myCotisations[0].operateur})`
      : 'Aucun paiement enregistré';

    const nowMs = Date.now();
    const upcomingEvents = (evenements || []).filter((e) => Date.parse(e.date) >= nowMs - 3600000);
    const nextEv = upcomingEvents[0] || (evenements && evenements[0]) || null;
    if (nextEv) {
      $('dash-next-event').textContent = nextEv.titre;
      $('dash-next-event-status').textContent = `${F.formatDateOnly(nextEv.date)} • ${nextEv.myResponse || 'En attente de réponse'}`;
    } else {
      $('dash-next-event').textContent = 'Aucun événement';
      $('dash-next-event-status').textContent = 'Rien de planifié pour le moment';
    }

    $('dash-rythme-label').textContent = association.rythme;
    Ui.renderPaymentCalendar($('dash-calendar-grid'), association, myCotisations, (receipt) => {
      openReceipt(receipt, membre.nom);
    });
    Ui.renderMyReceipts($('dash-my-receipts'), myCotisations, association.devise, (receipt) => {
      openReceipt(receipt, membre.nom);
    });
    Ui.renderEventsList($('dash-upcoming-events'), upcomingEvents.length ? upcomingEvents : evenements, {
      isBureau: permissions.isBureau,
      compact: true,
      onRespond: handleRespondEvent,
    });

    $('dash-members-count').textContent = String(membres.length);
    Ui.renderDashboardMembersPreview($('dash-members-preview'), membres, membre.id_membre, () => {
      switchWorkspaceTab('membres');
    });

    $('membres-count-label').textContent = `${membres.length} membre${membres.length > 1 ? 's' : ''}`;
    $('membres-assoc-label').textContent = association.nom;
    renderFilteredMembersDirectory();

    $('pay-devise-label').textContent = association.devise;
    const montantInput = $('pay-montant');
    if (!montantInput.dataset.touched) {
      if (association.montant) {
        montantInput.value = String(association.montant);
        $('pay-montant-hint').textContent = `Cotisation définie : ${F.formatMoney(association.montant, association.devise)}`;
      } else {
        montantInput.value = '';
        $('pay-montant-hint').textContent = 'Montant libre (facultatif dans cette association)';
      }
    }
    const periodeInput = $('pay-periode');
    if (!periodeInput.value) {
      periodeInput.value = F.getCurrentPeriodLabel(association.rythme, 0);
    }
    renderOperatorSelection();

    Ui.renderEventsList($('agenda-events-list'), evenements, {
      isBureau: permissions.isBureau,
      compact: false,
      onRespond: handleRespondEvent,
    });

    if (permissions.isBureau && registry) {
      $('bur-total-caisse').textContent = F.formatMoney(registry.stats.totalCaisse, association.devise);
      $('bur-total-tx').textContent = String(registry.stats.totalTransactions);
      $('bur-paying-members').textContent = `${registry.stats.payingMembersCount} / ${registry.stats.totalMembersCount}`;
      Ui.renderOperatorSummary($('bur-operators-summary'), registry.stats.byOperator, association.devise);
      renderFilteredRegistry();

      $('bur-roles-subtitle').textContent = permissions.isAdmin
        ? 'En tant qu’administrateur, vous pouvez attribuer les rôles du bureau (Président, Secrétaire, Trésorier...).'
        : 'Vue récapitulative des contributions par adhérent.';
      Ui.renderMembersTable($('bur-members-wrap'), registry.membres, association.devise, {
        isAdmin: permissions.isAdmin,
        currentMemberId: membre.id_membre,
        onChangeRole: handleChangeMemberRole,
      });
    }

    Ui.renderColorSwatches($('color-swatch-grid'), membre.couleur, handleSelectColor);
    Ui.renderProfileDetails($('profil-details'), association, membre);

    switchWorkspaceTab(state.activeWsTab);
  }

  function renderOperatorSelection() {
    Ui.renderOperatorGrid($('operator-grid'), state.selectedOperator, (opId) => {
      state.selectedOperator = opId;
      renderOperatorSelection();
    });
  }

  function renderFilteredRegistry() {
    const ws = state.workspace;
    if (!ws || !ws.registry) return;
    const query = ($('reg-search').value || '').trim().toLowerCase();
    const opFilter = $('reg-filter-op').value;

    const filtered = ws.registry.cotisations.filter((c) => {
      if (opFilter && c.operateur !== opFilter) return false;
      if (query) {
        const matchName = (c.membre_nom || '').toLowerCase().includes(query);
        const matchRec = (c.num_recu || '').toLowerCase().includes(query);
        const matchPeriode = (c.periode || '').toLowerCase().includes(query);
        return matchName || matchRec || matchPeriode;
      }
      return true;
    });

    Ui.renderRegistryTable($('bur-registry-table-wrap'), filtered, ws.association.devise, (receipt, memberName) => {
      openReceipt(receipt, memberName || ws.membre.nom);
    });
  }

  async function refreshWorkspace() {
    try {
      const data = await Api.getWorkspace();
      state.workspace = data;
      renderWorkspace();
    } catch (err) {
      if (err.status === 401) {
        exitToLanding();
      }
    }
  }

  async function enterWorkspace({ showCreatedModal = false, pinBureau = '' } = {}) {
    $('landing-view').classList.add('is-hidden');
    $('workspace-view').classList.remove('is-hidden');
    $('offline-banner').classList.toggle('is-hidden', !Api.IS_FILE_MODE);

    await refreshWorkspace();
    if (!state.workspace) return;

    if (showCreatedModal) {
      const { association } = state.workspace;
      $('created-code-value').textContent = association.code;
      $('created-pin-value').textContent = pinBureau;
      openModal('created-modal');
    }

    if (state.closeStream) {
      state.closeStream();
      state.closeStream = null;
    }
    state.closeStream = await Api.openRealtimeStream(
      () => {
        refreshWorkspace();
      },
      (status) => setSyncBadge(status)
    );

    if (state.syncPollTimer) clearInterval(state.syncPollTimer);
    if (!Api.IS_FILE_MODE) {
      state.syncPollTimer = setInterval(refreshWorkspace, 15000);
    }
  }

  function exitToLanding() {
    if (state.closeStream) {
      state.closeStream();
      state.closeStream = null;
    }
    if (state.syncPollTimer) {
      clearInterval(state.syncPollTimer);
      state.syncPollTimer = null;
    }
    state.workspace = null;
    state.activeWsTab = 'dashboard';
    F.applyTheme('emeraude');
    $('workspace-view').classList.add('is-hidden');
    $('landing-view').classList.remove('is-hidden');
  }

  async function handleJoinSubmit(ev) {
    ev.preventDefault();
    showError('join-error', '');
    const code = $('join-code').value.trim().toUpperCase();
    const nom = $('join-nom').value.trim();
    const pinBureau = $('join-pin').value.trim();

    try {
      const res = await Api.joinAssociation({ code, nom, pinBureau });
      $('pay-montant').dataset.touched = '';
      $('pay-periode').value = '';
      await enterWorkspace();
      Ui.showToast(
        res.joinedNew
          ? `Bienvenue ${res.membre.nom} ! Votre espace est prêt.`
          : `Bon retour, ${res.membre.nom} !`,
        'success'
      );
    } catch (err) {
      if (err.requiresPin) {
        $('join-pin-wrapper').classList.remove('is-hidden');
        $('join-pin').focus();
      }
      showError('join-error', err.message || 'Connexion impossible.');
    }
  }

  function openForgotCodeModal() {
    showError('forgot-error', '');
    const resultsBox = $('forgot-results');
    resultsBox.classList.add('is-hidden');
    const typedName = $('join-nom').value.trim();
    if (typedName && !$('forgot-nom').value.trim()) {
      $('forgot-nom').value = typedName;
    }
    openModal('forgot-code-modal');
    $('forgot-nom').focus();
  }

  async function handleRecoverCodeSubmit(ev) {
    ev.preventDefault();
    showError('forgot-error', '');
    const resultsBox = $('forgot-results');
    resultsBox.classList.add('is-hidden');

    const nom = $('forgot-nom').value.trim();
    const assocNom = $('forgot-assoc-nom').value.trim();

    try {
      const res = await Api.recoverCode({ nom, assocNom });
      Ui.renderForgotCodeResults(resultsBox, res.matches || [], {
        onCopyCode: (code) => copyCodeString(code),
        onUseMatch: (item) => {
          switchAuthTab('join');
          $('join-code').value = item.code;
          $('join-nom').value = item.membre_nom;
          showError('join-error', '');
          closeModal('forgot-code-modal');

          if (item.requiresPin) {
            $('join-pin-wrapper').classList.remove('is-hidden');
            $('join-pin').focus();
            Ui.showToast(`Code ${item.code} renseigné. Saisissez votre PIN Bureau pour vous connecter.`, 'info');
          } else {
            $('join-pin-wrapper').classList.add('is-hidden');
            $('join-pin').value = '';
            $('join-submit-btn').focus();
            Ui.showToast(`Code ${item.code} renseigné ! Cliquez sur « Accéder à mon espace ».`, 'success');
          }
        },
      });
    } catch (err) {
      showError('forgot-error', err.message || 'Impossible de retrouver le code.');
    }
  }

  async function handleCreateSubmit(ev) {
    ev.preventDefault();
    showError('create-error', '');
    const nom = $('create-nom').value.trim();
    const devise = $('create-devise').value;
    const rythme = $('create-rythme').value;
    const isLibre = $('create-montant-libre').checked;
    const montantVal = $('create-montant').value.trim();
    const montant = isLibre || montantVal === '' ? null : Number(montantVal);
    const fondateurNom = $('create-fondateur').value.trim();
    const pinBureau = $('create-pin').value.trim();

    try {
      const res = await Api.createAssociation({
        nom,
        devise,
        rythme,
        montant,
        fondateurNom,
        pinBureau,
      });
      $('pay-montant').dataset.touched = '';
      $('pay-periode').value = '';
      await enterWorkspace({ showCreatedModal: true, pinBureau: res.pinBureau });
    } catch (err) {
      showError('create-error', err.message || 'Impossible de créer l’association.');
    }
  }

  async function handleDemoLogin({ bureau = false } = {}) {
    try {
      if (bureau) {
        await Api.joinAssociation({ code: 'DEMO', nom: 'Mariam Touré', pinBureau: '2026' });
      } else {
        await Api.joinAssociation({ code: 'DEMO', nom: 'Aïcha Bamba' });
      }
      $('pay-montant').dataset.touched = '';
      $('pay-periode').value = '';
      await enterWorkspace();
      if (bureau) {
        switchWorkspaceTab('bureau');
        Ui.showToast('Mode DEMO ouvert côté Bureau (Mariam Touré, Trésorier).', 'info');
      } else {
        Ui.showToast('Mode DEMO ouvert dans l’espace membre d’Aïcha Bamba.', 'info');
      }
    } catch (err) {
      Ui.showToast(err.message, 'error');
    }
  }

  function handlePaymentSubmit(ev) {
    ev.preventDefault();
    showError('pay-error', '');
    const ws = state.workspace;
    if (!ws) return;

    const montant = Number($('pay-montant').value);
    const periode = $('pay-periode').value.trim();
    if (!Number.isFinite(montant) || montant <= 0) {
      showError('pay-error', 'Veuillez saisir un montant valide supérieur à 0.');
      return;
    }

    const opMeta = F.getOperatorMeta(state.selectedOperator);
    state.pendingPayment = {
      operateur: opMeta.id,
      montant,
      periode: periode || F.getCurrentPeriodLabel(ws.association.rythme, 0),
    };

    const banner = $('momo-op-banner');
    banner.textContent = opMeta.name;
    banner.style.backgroundColor = opMeta.color;
    banner.style.color = opMeta.ink;

    $('momo-assoc').textContent = ws.association.nom;
    $('momo-membre').textContent = ws.membre.nom;
    $('momo-operateur').textContent = opMeta.name;
    $('momo-periode').textContent = state.pendingPayment.periode;
    $('momo-montant').textContent = F.formatMoney(montant, ws.association.devise);

    $('momo-processing').classList.add('is-hidden');
    $('momo-confirm-btn').disabled = false;
    $('momo-cancel-btn').disabled = false;
    openModal('momo-modal');
  }

  async function confirmSimulatedPayment() {
    if (!state.pendingPayment) return;
    $('momo-processing').classList.remove('is-hidden');
    $('momo-confirm-btn').disabled = true;
    $('momo-cancel-btn').disabled = true;

    try {
      await new Promise((r) => setTimeout(r, 650));
      const res = await Api.payCotisation(state.pendingPayment);
      closeModal('momo-modal');
      state.pendingPayment = null;
      await refreshWorkspace();
      openReceipt(res.cotisation, res.membre.nom);
      Ui.showToast(`Cotisation validée ! Reçu ${res.cotisation.num_recu} généré.`, 'success');
    } catch (err) {
      $('momo-processing').classList.add('is-hidden');
      $('momo-confirm-btn').disabled = false;
      $('momo-cancel-btn').disabled = false;
      Ui.showToast(err.message || 'Paiement refusé.', 'error');
    }
  }

  function openReceipt(receipt, memberName) {
    const ws = state.workspace;
    if (!ws || !receipt) return;
    state.activeReceipt = receipt;
    state.activeReceiptMember = memberName || ws.membre.nom;

    $('rec-assoc-nom').textContent = ws.association.nom;
    $('rec-statut').textContent = `${receipt.statut} ✓`;
    $('rec-num').textContent = receipt.num_recu;
    $('rec-date').textContent = F.formatDateTime(receipt.date);
    $('rec-membre').textContent = state.activeReceiptMember;
    $('rec-operateur').textContent = receipt.operateur;
    $('rec-periode').textContent = receipt.periode || 'Cotisation';
    $('rec-montant').textContent = F.formatMoney(receipt.montant, ws.association.devise);

    openModal('receipt-modal');
  }

  async function handleRespondEvent(idEvent, reponse) {
    try {
      await Api.respondEvent(idEvent, reponse);
      await refreshWorkspace();
      Ui.showToast(
        reponse === 'Je participe' ? 'Participation confirmée (« Je participe ») !' : 'Réponse enregistrée : Indisponible.',
        'success'
      );
    } catch (err) {
      Ui.showToast(err.message, 'error');
    }
  }

  async function handleCreateEventSubmit(ev) {
    ev.preventDefault();
    showError('ev-error', '');
    const titre = $('ev-titre').value.trim();
    const type = $('ev-type').value;
    const date = $('ev-date').value;
    const description = $('ev-desc').value.trim();

    try {
      await Api.createEvent({ titre, type, date, description });
      $('ev-titre').value = '';
      $('ev-desc').value = '';
      await refreshWorkspace();
      Ui.showToast('Événement publié dans l’agenda partagé !', 'success');
    } catch (err) {
      showError('ev-error', err.message || 'Impossible de publier l’événement.');
    }
  }

  async function handleChangeMemberRole(idMembre, role) {
    try {
      await Api.updateMemberRole(idMembre, role);
      await refreshWorkspace();
      Ui.showToast(`Rôle mis à jour : ${role}`, 'success');
    } catch (err) {
      await refreshWorkspace();
      Ui.showToast(err.message, 'error');
    }
  }

  async function handleSelectColor(colorId) {
    try {
      F.applyTheme(colorId);
      await Api.updateColor(colorId);
      if (state.workspace) {
        state.workspace.membre.couleur = colorId;
        Ui.renderColorSwatches($('color-swatch-grid'), colorId, handleSelectColor);
        await refreshWorkspace();
      }
      Ui.showToast(`Couleur « ${F.THEMES[colorId].label} » enregistrée.`, 'success');
    } catch (err) {
      Ui.showToast(err.message, 'error');
    }
  }

  async function handleExportCsv() {
    try {
      const { blob, filename } = await Api.exportRegistryCsv();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      Ui.showToast('Registre exporté au format CSV (Excel).', 'success');
    } catch (err) {
      Ui.showToast(err.message, 'error');
    }
  }

  function setDefaultEventInputDate() {
    const dt = new Date(Date.now() + 3 * 86400000);
    dt.setHours(18, 0, 0, 0);
    const localIso = new Date(dt.getTime() - dt.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    $('ev-date').value = localIso;
  }

  function init() {
    document.querySelectorAll('.auth-tab').forEach((btn) => {
      btn.addEventListener('click', () => switchAuthTab(btn.dataset.authTab));
    });

    document.querySelectorAll('.merise-tab').forEach((btn) => {
      btn.addEventListener('click', () => switchMeriseTab(btn.dataset.meriseTab));
    });

    $('header-demo-btn').addEventListener('click', () => {
      switchAuthTab('demo');
      $('acces-plateforme').scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    $('forgot-code-btn').addEventListener('click', openForgotCodeModal);
    $('forgot-code-form').addEventListener('submit', handleRecoverCodeSubmit);
    $('forgot-close-btn').addEventListener('click', () => closeModal('forgot-code-modal'));
    $('forgot-close-x').addEventListener('click', () => closeModal('forgot-code-modal'));

    $('toggle-bureau-pin-btn').addEventListener('click', () => {
      const wrap = $('join-pin-wrapper');
      wrap.classList.toggle('is-hidden');
      if (!wrap.classList.contains('is-hidden')) {
        $('join-pin').focus();
      }
    });

    $('join-code').addEventListener('input', (e) => {
      e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    });

    $('create-montant-libre').addEventListener('change', (e) => {
      const input = $('create-montant');
      input.disabled = e.target.checked;
      if (e.target.checked) input.value = '';
    });

    $('join-form').addEventListener('submit', handleJoinSubmit);
    $('create-form').addEventListener('submit', handleCreateSubmit);
    $('demo-member-btn').addEventListener('click', () => handleDemoLogin({ bureau: false }));
    $('demo-bureau-btn').addEventListener('click', () => handleDemoLogin({ bureau: true }));

    document.querySelectorAll('[data-ws-tab]').forEach((btn) => {
      btn.addEventListener('click', () => switchWorkspaceTab(btn.dataset.wsTab));
    });

    $('dash-pay-cta').addEventListener('click', () => switchWorkspaceTab('cotiser'));
    $('dash-go-pay-link').addEventListener('click', () => switchWorkspaceTab('cotiser'));
    $('dash-go-agenda-link').addEventListener('click', () => switchWorkspaceTab('agenda'));
    $('dash-go-membres-link').addEventListener('click', () => switchWorkspaceTab('membres'));
    $('membres-invite-btn').addEventListener('click', () => {
      if (state.workspace) shareOnWhatsApp(state.workspace.association);
    });
    $('membres-search').addEventListener('input', renderFilteredMembersDirectory);
    $('membres-filter-role').addEventListener('change', renderFilteredMembersDirectory);

    $('agenda-new-event-btn').addEventListener('click', () => {
      switchWorkspaceTab('bureau');
      $('ev-titre').focus();
    });

    $('ws-copy-code-btn').addEventListener('click', () => {
      if (state.workspace) copyInvite(state.workspace.association);
    });
    $('sidebar-whatsapp-btn').addEventListener('click', () => {
      if (state.workspace) shareOnWhatsApp(state.workspace.association);
    });
    $('bureau-whatsapp-btn').addEventListener('click', () => {
      if (state.workspace) shareOnWhatsApp(state.workspace.association);
    });

    $('ws-logout-btn').addEventListener('click', async () => {
      await Api.logout();
      exitToLanding();
      Ui.showToast('Vous êtes déconnecté.', 'info');
    });
    $('profil-logout-btn').addEventListener('click', async () => {
      await Api.logout();
      exitToLanding();
      Ui.showToast('Vous êtes déconnecté.', 'info');
    });

    $('pay-montant').addEventListener('input', (e) => {
      e.target.dataset.touched = '1';
    });
    $('payment-form').addEventListener('submit', handlePaymentSubmit);
    $('momo-cancel-btn').addEventListener('click', () => closeModal('momo-modal'));
    $('momo-confirm-btn').addEventListener('click', confirmSimulatedPayment);

    $('created-copy-btn').addEventListener('click', async () => {
      if (!state.workspace) return;
      const text = buildInviteText(state.workspace.association);
      try {
        await navigator.clipboard.writeText(text);
        Ui.showToast('Message d’invitation copié !', 'success');
      } catch {
        Ui.showToast(`Code : ${state.workspace.association.code}`, 'info');
      }
    });
    $('created-whatsapp-btn').addEventListener('click', () => {
      if (state.workspace) shareOnWhatsApp(state.workspace.association);
    });
    $('created-enter-btn').addEventListener('click', () => closeModal('created-modal'));

    $('reg-search').addEventListener('input', renderFilteredRegistry);
    $('reg-filter-op').addEventListener('change', renderFilteredRegistry);
    $('create-event-form').addEventListener('submit', handleCreateEventSubmit);
    $('bureau-export-csv-btn').addEventListener('click', handleExportCsv);
    setDefaultEventInputDate();

    $('rec-close-btn').addEventListener('click', () => closeModal('receipt-modal'));
    $('rec-print-btn').addEventListener('click', () => window.print());
    $('rec-download-btn').addEventListener('click', () => {
      if (!state.activeReceipt || !state.workspace) return;
      const content = Ui.formatReceiptText(
        state.activeReceipt,
        state.activeReceiptMember,
        state.workspace.association
      );
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${state.activeReceipt.num_recu}.txt`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });

    ['receipt-modal', 'created-modal', 'forgot-code-modal'].forEach((modalId) => {
      $(modalId).addEventListener('click', (e) => {
        if (e.target === $(modalId)) closeModal(modalId);
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeModal('receipt-modal');
        closeModal('momo-modal');
        closeModal('created-modal');
        closeModal('forgot-code-modal');
      }
    });

    if (Api.getToken()) {
      enterWorkspace().catch(() => {
        Api.setToken(null);
      });
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
