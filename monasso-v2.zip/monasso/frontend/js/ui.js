window.MonAssoUi = (function () {
  'use strict';

  const F = window.MonAssoFormatters;

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = el('div', `toast toast-${type}`, message);
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('toast-leave');
      setTimeout(() => toast.remove(), 250);
    }, 3400);
  }

  function createOperatorBadge(opName) {
    const meta = F.getOperatorMeta(opName);
    const badge = el('span', 'op-badge');
    badge.style.backgroundColor = meta.soft;
    badge.style.color = meta.id === 'MTN MoMo' ? '#8A6900' : meta.color;
    badge.style.borderColor = meta.color;
    const dot = el('span', 'op-badge-dot');
    dot.style.backgroundColor = meta.color;
    badge.appendChild(dot);
    badge.appendChild(document.createTextNode(meta.name));
    return badge;
  }

  function renderPaymentCalendar(container, association, cotisations, onOpenReceipt) {
    clear(container);
    const periods = F.buildPaymentCalendar(association, cotisations);
    periods.forEach((p) => {
      const card = el(
        'div',
        `cal-cell ${p.paid ? 'is-paid' : p.isCurrent ? 'is-current' : 'is-future'}`
      );
      const top = el('div', 'cal-top');
      top.appendChild(el('span', 'cal-period', p.label));
      if (p.paid) {
        top.appendChild(el('span', 'cal-status cal-status-paid', 'Payée ✓'));
      } else if (p.isCurrent) {
        top.appendChild(el('span', 'cal-status cal-status-due', 'À régler'));
      } else {
        top.appendChild(el('span', 'cal-status cal-status-future', 'À venir'));
      }
      card.appendChild(top);

      if (p.receipt) {
        const sub = el('button', 'cal-receipt-link', `Reçu ${p.receipt.num_recu}`);
        sub.type = 'button';
        sub.addEventListener('click', () => onOpenReceipt(p.receipt));
        card.appendChild(sub);
      } else {
        const hint = el(
          'small',
          'cal-hint',
          association.montant ? F.formatMoney(association.montant, association.devise) : 'Montant libre'
        );
        card.appendChild(hint);
      }
      container.appendChild(card);
    });
  }

  function renderMyReceipts(container, cotisations, devise, onOpenReceipt) {
    clear(container);
    if (!cotisations || cotisations.length === 0) {
      const empty = el('div', 'empty-state');
      empty.appendChild(el('p', null, 'Vous n’avez encore effectué aucune cotisation.'));
      empty.appendChild(el('small', null, 'Cliquez sur « Payer ma cotisation » pour simuler un versement Mobile Money.'));
      container.appendChild(empty);
      return;
    }

    cotisations.forEach((c) => {
      const row = el('div', 'receipt-row');
      const left = el('div', 'receipt-row-left');
      const titleLine = el('div', 'receipt-row-title');
      titleLine.appendChild(el('strong', 'mono-text', c.num_recu));
      titleLine.appendChild(createOperatorBadge(c.operateur));
      left.appendChild(titleLine);

      const metaText = c.periode
        ? `${c.periode} • ${F.formatDateTime(c.date)}`
        : F.formatDateTime(c.date);
      left.appendChild(el('small', 'muted-text', metaText));

      const right = el('div', 'receipt-row-right');
      right.appendChild(el('strong', 'amount-text', F.formatMoney(c.montant, devise)));
      const btn = el('button', 'btn btn-soft btn-xs', 'Voir reçu');
      btn.type = 'button';
      btn.addEventListener('click', () => onOpenReceipt(c));
      right.appendChild(btn);

      row.appendChild(left);
      row.appendChild(right);
      container.appendChild(row);
    });
  }

  function renderOperatorGrid(container, selectedOp, onSelect) {
    clear(container);
    F.OPERATORS.forEach((op) => {
      const btn = el('button', `operator-card ${selectedOp === op.id ? 'is-selected' : ''}`);
      btn.type = 'button';
      btn.setAttribute('aria-pressed', selectedOp === op.id ? 'true' : 'false');

      const badge = el('span', 'op-logo', op.short);
      badge.style.backgroundColor = op.color;
      badge.style.color = op.ink;

      const info = el('span', 'op-info');
      info.appendChild(el('strong', null, op.name));
      info.appendChild(el('small', null, op.hint));

      btn.appendChild(badge);
      btn.appendChild(info);
      btn.addEventListener('click', () => onSelect(op.id));
      container.appendChild(btn);
    });
  }

  function renderEventsList(container, events, { isBureau = false, compact = false, onRespond }) {
    clear(container);
    const list = compact ? (events || []).slice(0, 3) : (events || []);
    if (list.length === 0) {
      const empty = el('div', 'empty-state');
      empty.appendChild(el('p', null, 'Aucun événement publié pour le moment.'));
      empty.appendChild(el('small', null, isBureau ? 'Publiez une réunion ou activité depuis l’espace Bureau.' : 'Le bureau publiera ici les prochaines réunions et activités.'));
      container.appendChild(empty);
      return;
    }

    list.forEach((ev) => {
      const card = el('article', 'event-card');
      const top = el('div', 'event-top');
      top.appendChild(el('span', `event-type-badge type-${ev.type.toLowerCase().replace(/[^a-z]/g, '')}`, ev.type));
      top.appendChild(el('span', 'event-count', `${ev.participantsCount} participant${ev.participantsCount > 1 ? 's' : ''}`));
      card.appendChild(top);

      card.appendChild(el('h3', 'event-title', ev.titre));
      card.appendChild(el('p', 'event-date', `📆 ${F.formatDateFull(ev.date)}`));
      if (ev.description && !compact) {
        card.appendChild(el('p', 'event-desc', ev.description));
      }

      const actions = el('div', 'event-actions');
      const isParticipating = ev.myResponse === 'Je participe';
      const isDeclined = ev.myResponse === 'Indisponible';

      const btnYes = el(
        'button',
        `btn btn-sm ${isParticipating ? 'btn-primary' : 'btn-outline'}`,
        isParticipating ? '✓ Je participe' : 'Je participe'
      );
      btnYes.type = 'button';
      btnYes.addEventListener('click', () => onRespond(ev.id_event, 'Je participe'));
      actions.appendChild(btnYes);

      if (!compact) {
        const btnNo = el(
          'button',
          `btn btn-sm ${isDeclined ? 'btn-dark-soft' : 'btn-soft'}`,
          isDeclined ? 'Indisponible ✓' : 'Indisponible'
        );
        btnNo.type = 'button';
        btnNo.addEventListener('click', () => onRespond(ev.id_event, 'Indisponible'));
        actions.appendChild(btnNo);
      }

      card.appendChild(actions);

      if (!compact && isBureau && Array.isArray(ev.participants) && ev.participants.length > 0) {
        const details = el('details', 'event-participants-details');
        details.appendChild(el('summary', null, `Voir les réponses (${ev.participants.length})`));
        const ul = el('ul', 'participants-mini-list');
        ev.participants.forEach((p) => {
          const li = el('li');
          li.appendChild(el('span', null, `${p.nom} (${p.role})`));
          li.appendChild(el('strong', p.reponse === 'Je participe' ? 'text-ok' : 'muted-text', p.reponse));
          ul.appendChild(li);
        });
        details.appendChild(ul);
        card.appendChild(details);
      }

      container.appendChild(card);
    });
  }

  function renderMembersDirectory(container, members, currentMemberId) {
    clear(container);
    if (!members || members.length === 0) {
      const empty = el('div', 'empty-state');
      empty.appendChild(el('p', null, 'Aucun membre ne correspond à votre recherche.'));
      container.appendChild(empty);
      return;
    }

    members.forEach((m) => {
      const theme = F.THEMES[m.couleur] || F.THEMES.emeraude;
      const isSelf = m.id_membre === currentMemberId;
      const card = el('article', `member-dir-card ${isSelf ? 'is-self' : ''}`);

      const avatar = el('div', 'member-dir-avatar', (m.nom || 'M').trim().charAt(0).toUpperCase());
      avatar.style.backgroundColor = theme.accentSoft;
      avatar.style.color = theme.accentStrong;
      avatar.style.borderColor = theme.accent;

      const body = el('div', 'member-dir-body');
      const nameRow = el('div', 'member-dir-name-row');
      nameRow.appendChild(el('strong', 'member-dir-name', m.nom));
      if (isSelf) {
        nameRow.appendChild(el('span', 'you-chip', 'Vous'));
      }
      body.appendChild(nameRow);

      const metaRow = el('div', 'member-dir-meta');
      metaRow.appendChild(el('span', `role-badge ${F.isBureauRole(m.role) ? 'role-bureau' : ''}`, m.role));
      if (m.created_at) {
        metaRow.appendChild(el('small', 'muted-text', `Inscrit le ${F.formatDateOnly(m.created_at)}`));
      }
      body.appendChild(metaRow);

      card.appendChild(avatar);
      card.appendChild(body);
      container.appendChild(card);
    });
  }

  function renderDashboardMembersPreview(container, members, currentMemberId, onViewAll) {
    clear(container);
    if (!members || members.length === 0) {
      const empty = el('div', 'empty-state');
      empty.appendChild(el('p', null, 'Aucun membre enregistré pour le moment.'));
      container.appendChild(empty);
      return;
    }

    const preview = members.slice(0, 6);
    preview.forEach((m) => {
      const theme = F.THEMES[m.couleur] || F.THEMES.emeraude;
      const chip = el('button', 'member-preview-chip');
      chip.type = 'button';
      chip.addEventListener('click', onViewAll);

      const dot = el('span', 'member-preview-avatar', (m.nom || 'M').trim().charAt(0).toUpperCase());
      dot.style.backgroundColor = theme.accentSoft;
      dot.style.color = theme.accentStrong;

      const info = el('span', 'member-preview-info');
      const label = m.id_membre === currentMemberId ? `${m.nom} (Vous)` : m.nom;
      info.appendChild(el('strong', null, label));
      info.appendChild(el('small', null, m.role));

      chip.appendChild(dot);
      chip.appendChild(info);
      container.appendChild(chip);
    });

    if (members.length > 6) {
      const moreBtn = el('button', 'member-preview-more', `+${members.length - 6} autre${members.length - 6 > 1 ? 's' : ''}`);
      moreBtn.type = 'button';
      moreBtn.addEventListener('click', onViewAll);
      container.appendChild(moreBtn);
    }
  }

  function renderForgotCodeResults(container, matches, { onCopyCode, onUseMatch }) {
    clear(container);
    container.classList.remove('is-hidden');

    container.appendChild(
      el(
        'p',
        'forgot-results-head',
        `${matches.length} association${matches.length > 1 ? 's' : ''} trouvée${matches.length > 1 ? 's' : ''} :`
      )
    );

    matches.forEach((item) => {
      const card = el('div', 'forgot-result-card');

      const header = el('div', 'forgot-result-top');
      const info = el('div', 'forgot-result-info');
      info.appendChild(el('strong', null, item.nom_association));
      info.appendChild(
        el('small', 'muted-text', `${item.membre_nom} • ${item.role} (${item.rythme} • ${item.devise})`)
      );
      header.appendChild(info);

      const codeWrap = el('div', 'forgot-code-pill-wrap');
      codeWrap.appendChild(el('strong', 'forgot-code-value', item.code));
      const copyBtn = el('button', 'btn btn-soft btn-xs', 'Copier');
      copyBtn.type = 'button';
      copyBtn.addEventListener('click', () => onCopyCode(item.code));
      codeWrap.appendChild(copyBtn);

      header.appendChild(codeWrap);
      card.appendChild(header);

      if (item.requiresPin) {
        card.appendChild(
          el('small', 'forgot-pin-note', 'Profil Bureau : votre code PIN Bureau sera demandé à la connexion.')
        );
      }

      const useBtn = el('button', 'btn btn-primary btn-sm btn-block', 'Utiliser ce code pour me connecter');
      useBtn.type = 'button';
      useBtn.addEventListener('click', () => onUseMatch(item));
      card.appendChild(useBtn);

      container.appendChild(card);
    });
  }

  function renderRegistryTable(container, cotisations, devise, onOpenReceipt) {
    clear(container);
    if (!cotisations || cotisations.length === 0) {
      const empty = el('div', 'empty-state');
      empty.appendChild(el('p', null, 'Aucune cotisation ne correspond à ce filtre.'));
      container.appendChild(empty);
      return;
    }

    const table = el('table', 'data-table');
    const thead = el('thead');
    const headRow = el('tr');
    ['N° Reçu', 'Date & Heure', 'Membre', 'Opérateur', 'Montant', 'Statut', 'Action'].forEach((h) => {
      headRow.appendChild(el('th', null, h));
    });
    thead.appendChild(headRow);
    table.appendChild(thead);

    const tbody = el('tbody');
    cotisations.forEach((c) => {
      const tr = el('tr');
      const tdRec = el('td');
      tdRec.appendChild(el('code', 'mono-text', c.num_recu));
      tr.appendChild(tdRec);

      tr.appendChild(el('td', null, F.formatDateTime(c.date)));

      const tdMember = el('td');
      tdMember.appendChild(el('strong', null, c.membre_nom));
      if (c.periode) {
        tdMember.appendChild(el('div', 'table-sub', c.periode));
      }
      tr.appendChild(tdMember);

      const tdOp = el('td');
      tdOp.appendChild(createOperatorBadge(c.operateur));
      tr.appendChild(tdOp);

      tr.appendChild(el('td', 'amount-cell', F.formatMoney(c.montant, devise)));

      const tdStat = el('td');
      tdStat.appendChild(el('span', 'status-badge status-valid', c.statut));
      tr.appendChild(tdStat);

      const tdAct = el('td');
      const btn = el('button', 'btn btn-soft btn-xs', 'Reçu');
      btn.type = 'button';
      btn.addEventListener('click', () => onOpenReceipt(c, c.membre_nom));
      tdAct.appendChild(btn);
      tr.appendChild(tdAct);

      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    container.appendChild(table);
  }

  function renderMembersTable(container, members, devise, { isAdmin, currentMemberId, onChangeRole }) {
    clear(container);
    const table = el('table', 'data-table');
    const thead = el('thead');
    const headRow = el('tr');
    ['Membre', 'Rôle', 'Cotisations', 'Total versé', 'Dernier paiement'].forEach((h) => {
      headRow.appendChild(el('th', null, h));
    });
    thead.appendChild(headRow);
    table.appendChild(thead);

    const tbody = el('tbody');
    const availableRoles = ['Membre', 'Trésorier', 'Secrétaire', 'Président', 'Bureau', 'Administrateur'];

    members.forEach((m) => {
      const tr = el('tr');
      const tdNom = el('td');
      tdNom.appendChild(el('strong', null, m.nom));
      if (m.id_membre === currentMemberId) {
        tdNom.appendChild(el('span', 'you-chip', 'Vous'));
      }
      tr.appendChild(tdNom);

      const tdRole = el('td');
      if (isAdmin) {
        const select = el('select', 'role-select');
        select.setAttribute('aria-label', `Rôle de ${m.nom}`);
        availableRoles.forEach((r) => {
          const opt = el('option', null, r);
          opt.value = r;
          if (r === m.role) opt.selected = true;
          select.appendChild(opt);
        });
        select.addEventListener('change', () => onChangeRole(m.id_membre, select.value));
        tdRole.appendChild(select);
      } else {
        tdRole.appendChild(el('span', `role-badge ${F.isBureauRole(m.role) ? 'role-bureau' : ''}`, m.role));
      }
      tr.appendChild(tdRole);

      tr.appendChild(el('td', null, String(m.nb_cotisations)));
      tr.appendChild(el('td', 'amount-cell', F.formatMoney(m.total_verse, devise)));
      tr.appendChild(el('td', null, m.dernier_paiement ? F.formatDateOnly(m.dernier_paiement) : 'Aucun'));
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    container.appendChild(table);
  }

  function renderOperatorSummary(container, byOperator, devise) {
    clear(container);
    const entries = Object.entries(byOperator || {}).filter(([, val]) => Number(val) > 0);
    if (entries.length === 0) {
      container.appendChild(el('small', 'kpi-sub', 'Aucune transaction'));
      return;
    }
    entries.forEach(([op, val]) => {
      const line = el('div', 'op-mini-line');
      line.appendChild(el('span', null, op));
      line.appendChild(el('strong', null, F.formatMoney(val, devise)));
      container.appendChild(line);
    });
  }

  function renderColorSwatches(container, activeColor, onSelectColor) {
    clear(container);
    Object.values(F.THEMES).forEach((t) => {
      const btn = el('button', `swatch-card ${activeColor === t.id ? 'is-active' : ''}`);
      btn.type = 'button';
      const circle = el('span', 'swatch-circle');
      circle.style.backgroundColor = t.accent;
      btn.appendChild(circle);
      btn.appendChild(el('span', 'swatch-label', t.label));
      if (activeColor === t.id) {
        btn.appendChild(el('span', 'swatch-check', '✓'));
      }
      btn.addEventListener('click', () => onSelectColor(t.id));
      container.appendChild(btn);
    });
  }

  function renderProfileDetails(container, association, membre) {
    clear(container);
    const rows = [
      ['Association', association.nom],
      ['Code d’invitation', association.code],
      ['Rythme', association.rythme],
      ['Cotisation de référence', association.montant ? F.formatMoney(association.montant, association.devise) : 'Montant libre / facultatif'],
      ['Devise', association.devise],
      ['Votre nom', membre.nom],
      ['Votre rôle', membre.role],
    ];
    rows.forEach(([label, value]) => {
      const wrapper = el('div');
      wrapper.appendChild(el('dt', null, label));
      wrapper.appendChild(el('dd', null, value));
      container.appendChild(wrapper);
    });
  }

  function formatReceiptText(receipt, memberName, association) {
    return [
      '========================================',
      '           MONASSO — REÇU OFFICIEL       ',
      '========================================',
      `Association : ${association.nom} (${association.code})`,
      `N° de reçu  : ${receipt.num_recu}`,
      `Date/Heure  : ${F.formatDateTime(receipt.date)}`,
      `Membre      : ${memberName}`,
      `Opérateur   : ${receipt.operateur}`,
      `Période     : ${receipt.periode || 'Cotisation'}`,
      `Montant     : ${F.formatMoney(receipt.montant, association.devise)}`,
      `Statut      : ${receipt.statut}`,
      '========================================',
      'Généré automatiquement par MonAsso.',
    ].join('\n');
  }

  return {
    showToast,
    renderPaymentCalendar,
    renderMyReceipts,
    renderOperatorGrid,
    renderEventsList,
    renderMembersDirectory,
    renderDashboardMembersPreview,
    renderForgotCodeResults,
    renderRegistryTable,
    renderMembersTable,
    renderOperatorSummary,
    renderColorSwatches,
    renderProfileDetails,
    formatReceiptText,
  };
})();
