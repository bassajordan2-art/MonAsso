'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { createAppServer } = require('../backend/server');

async function startTestServer() {
  const { server, db } = createAppServer({ dbPath: ':memory:' });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  const baseUrl = `http://127.0.0.1:${port}`;
  return { server, db, baseUrl };
}

async function apiFetch(baseUrl, path, { method = 'GET', token, body } = {}) {
  const headers = { Accept: 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = text;
  }
  return { status: res.status, headers: res.headers, data: json };
}

test('Scénario complet MonAsso (6 étapes + annuaire membres + récupération code oublié)', async () => {
  const { server, baseUrl } = await startTestServer();
  try {
    const createRes = await apiFetch(baseUrl, '/api/associations', {
      method: 'POST',
      body: {
        nom: 'Tontine Fraternité UNA',
        montant: 15000,
        rythme: 'Mensuel',
        devise: 'FCFA',
        fondateurNom: 'Kouamé Yao',
        pinBureau: '4321',
      },
    });
    assert.equal(createRes.status, 201);
    assert.match(createRes.data.association.code, /^[A-Z0-9]{6}$/);
    assert.equal(createRes.data.membre.role, 'Administrateur');
    assert.equal(createRes.data.permissions.isBureau, true);
    const assocCode = createRes.data.association.code;
    const adminToken = createRes.data.token;

    const joinRes = await apiFetch(baseUrl, '/api/associations/join', {
      method: 'POST',
      body: {
        code: assocCode,
        nom: 'Awa Traoré',
      },
    });
    assert.equal(joinRes.status, 200);
    assert.equal(joinRes.data.membre.role, 'Membre');
    assert.equal(joinRes.data.permissions.isBureau, false);
    const memberToken = joinRes.data.token;

    // Chaque membre voit tous les autres membres de son association, mais pas le registre financier
    const memberWsBefore = await apiFetch(baseUrl, '/api/workspace', { token: memberToken });
    assert.equal(memberWsBefore.status, 200);
    assert.equal(memberWsBefore.data.registry, null);
    assert.equal(memberWsBefore.data.membres.length, 2);
    assert.deepEqual(
      memberWsBefore.data.membres.map((m) => m.nom),
      ['Kouamé Yao', 'Awa Traoré']
    );

    // Récupération de code oublié pour un membre simple et pour un administrateur
    const recoverMember = await apiFetch(baseUrl, '/api/associations/recover-code', {
      method: 'POST',
      body: { nom: 'Awa Traoré' },
    });
    assert.equal(recoverMember.status, 200);
    assert.equal(recoverMember.data.matches.length, 1);
    assert.equal(recoverMember.data.matches[0].code, assocCode);
    assert.equal(recoverMember.data.matches[0].requiresPin, false);

    const recoverAdmin = await apiFetch(baseUrl, '/api/associations/recover-code', {
      method: 'POST',
      body: { nom: 'Kouamé Yao', assocNom: 'UNA' },
    });
    assert.equal(recoverAdmin.status, 200);
    assert.equal(recoverAdmin.data.matches[0].code, assocCode);
    assert.equal(recoverAdmin.data.matches[0].requiresPin, true);

    const recoverUnknown = await apiFetch(baseUrl, '/api/associations/recover-code', {
      method: 'POST',
      body: { nom: 'Inconnu Total' },
    });
    assert.equal(recoverUnknown.status, 404);

    const forbiddenEvent = await apiFetch(baseUrl, '/api/evenements', {
      method: 'POST',
      token: memberToken,
      body: {
        titre: 'Réunion pirate',
        type: 'Réunion',
        date: '2026-12-10T18:00:00Z',
      },
    });
    assert.equal(forbiddenEvent.status, 403);

    const payRes = await apiFetch(baseUrl, '/api/cotisations', {
      method: 'POST',
      token: memberToken,
      body: {
        operateur: 'Wave',
        montant: 15000,
        periode: 'Novembre 2026',
      },
    });
    assert.equal(payRes.status, 201);
    assert.match(payRes.data.cotisation.num_recu, /^REC-\d{8}-\d{6}$/);
    assert.equal(payRes.data.cotisation.statut, 'Validée');

    const adminWs = await apiFetch(baseUrl, '/api/workspace', { token: adminToken });
    assert.equal(adminWs.status, 200);
    assert.equal(adminWs.data.registry.stats.totalCaisse, 15000);
    assert.equal(adminWs.data.registry.cotisations.length, 1);
    assert.equal(adminWs.data.registry.cotisations[0].membre_nom, 'Awa Traoré');

    const evRes = await apiFetch(baseUrl, '/api/evenements', {
      method: 'POST',
      token: adminToken,
      body: {
        titre: 'Assemblée générale de bilan',
        type: 'Assemblée générale',
        date: '2026-12-15T10:00:00Z',
        description: 'Amphithéâtre UNA',
      },
    });
    assert.equal(evRes.status, 201);
    const idEvent = evRes.data.evenement.id_event;

    const partRes = await apiFetch(baseUrl, `/api/evenements/${idEvent}/participer`, {
      method: 'POST',
      token: memberToken,
      body: { reponse: 'Je participe' },
    });
    assert.equal(partRes.status, 200);

    const colorRes = await apiFetch(baseUrl, '/api/membres/me/couleur', {
      method: 'PATCH',
      token: memberToken,
      body: { couleur: 'terracotta' },
    });
    assert.equal(colorRes.status, 200);
    assert.equal(colorRes.data.membre.couleur, 'terracotta');

    const memberWsAfter = await apiFetch(baseUrl, '/api/workspace', { token: memberToken });
    assert.equal(memberWsAfter.data.evenements[0].participantsCount, 1);
    assert.equal(memberWsAfter.data.evenements[0].myResponse, 'Je participe');
    assert.equal(memberWsAfter.data.myCotisations.length, 1);

    const csvDenied = await apiFetch(baseUrl, '/api/registry/export', { token: memberToken });
    assert.equal(csvDenied.status, 403);
    const csvOk = await apiFetch(baseUrl, '/api/registry/export', { token: adminToken });
    assert.equal(csvOk.status, 200);
    assert.ok(String(csvOk.data).includes('Awa Traoré'));
  } finally {
    server.close();
  }
});

test('Mode DEMO, protection PIN Bureau et limitation des tentatives (429)', async () => {
  const { server, baseUrl } = await startTestServer();
  try {
    const demoMember = await apiFetch(baseUrl, '/api/associations/join', {
      method: 'POST',
      body: { code: 'DEMO', nom: '' },
    });
    assert.equal(demoMember.status, 200);
    assert.equal(demoMember.data.membre.nom, 'Aïcha Bamba');
    assert.equal(demoMember.data.permissions.isBureau, false);

    const spoofAttempt = await apiFetch(baseUrl, '/api/associations/join', {
      method: 'POST',
      body: { code: 'DEMO', nom: 'Mariam Touré' },
    });
    assert.equal(spoofAttempt.status, 401);
    assert.equal(spoofAttempt.data.requiresPin, true);

    const bureauDemo = await apiFetch(baseUrl, '/api/associations/join', {
      method: 'POST',
      body: { code: 'DEMO', nom: 'Mariam Touré', pinBureau: '2026' },
    });
    assert.equal(bureauDemo.status, 200);
    assert.equal(bureauDemo.data.permissions.isBureau, true);

    for (let i = 0; i < 6; i += 1) {
      const bad = await apiFetch(baseUrl, '/api/associations/join', {
        method: 'POST',
        body: { code: 'ZZZZ99', nom: 'Test' },
      });
      assert.equal(bad.status, 404);
    }
    const blocked = await apiFetch(baseUrl, '/api/associations/join', {
      method: 'POST',
      body: { code: 'ZZZZ99', nom: 'Test' },
    });
    assert.equal(blocked.status, 429);
  } finally {
    server.close();
  }
});

test('Flux temps réel SSE & fichiers statiques avec en-têtes OWASP', async () => {
  const { server, baseUrl } = await startTestServer();
  try {
    const htmlRes = await fetch(`${baseUrl}/`);
    assert.equal(htmlRes.status, 200);
    assert.equal(htmlRes.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(htmlRes.headers.get('x-frame-options'), 'DENY');
    assert.ok(htmlRes.headers.get('content-security-policy').includes("script-src 'self'"));

    const join = await apiFetch(baseUrl, '/api/associations/join', {
      method: 'POST',
      body: { code: 'DEMO', nom: 'Aïcha Bamba' },
    });
    const token = join.data.token;

    const ticketRes = await apiFetch(baseUrl, '/api/auth/stream-ticket', {
      method: 'POST',
      token,
    });
    assert.equal(ticketRes.status, 200);

    const controller = new AbortController();
    const sseRes = await fetch(`${baseUrl}/api/stream?ticket=${ticketRes.data.ticket}`, {
      signal: controller.signal,
    });
    assert.equal(sseRes.status, 200);
    const reader = sseRes.body.getReader();

    await apiFetch(baseUrl, '/api/cotisations', {
      method: 'POST',
      token,
      body: { operateur: 'Orange Money', montant: 10000, periode: 'Décembre 2026' },
    });

    let collected = '';
    const decoder = new TextDecoder();
    for (let i = 0; i < 4; i += 1) {
      const { value, done } = await reader.read();
      if (done) break;
      collected += decoder.decode(value, { stream: true });
      if (collected.includes('event: sync')) break;
    }
    controller.abort();
    assert.ok(collected.includes('event: connected'));
    assert.ok(collected.includes('event: sync'));
  } finally {
    server.close();
  }
});
