@echo off
chcp 65001 >nul
echo ===================================================
echo   MonAsso - Plateforme Associations ^& Tontines
echo ===================================================
echo.

node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] Node.js n'est pas installe. Telechargez Node.js 22+ sur https://nodejs.org
    pause
    exit /b 1
)

cd /d "%~dp0"
echo Demarrage du serveur centralise (HTML/CSS/JS + SQLite)...
echo.
start "MonAsso - Serveur" cmd /k "node backend/server.js"

timeout /t 2 /nobreak >nul
start http://localhost:3000

echo Application ouverte sur http://localhost:3000
echo Code de demonstration : DEMO  (PIN Bureau Demo : 2026)
echo.
pause
