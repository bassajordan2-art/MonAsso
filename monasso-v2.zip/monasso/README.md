# MonAsso — Plateforme numérique pour la gestion des associations et des tontines

Projet réalisé dans le cadre de l’exposé du **Groupe 1 — Université Nangui Abrogoua (Année universitaire 2026-2027)**.

## Aperçu

**MonAsso** est une application web mobile-first et responsive permettant aux associations, amicales, mutuelles, tontines (ROSCA) et associations de parents d’élèves de gérer au même endroit :
- Les **cotisations** via un parcours simulé Mobile Money (**Wave**, **Orange Money**, **MTN MoMo**, **Moov Money**) avec génération automatique d’un **reçu horodaté** (`REC-...`) et mise à jour du registre en temps réel.
- L’**agenda partagé** (réunions, activités, assemblées générales) avec confirmation **« Je participe »** en un clic.
- L’**annuaire des membres** permettant à chaque adhérent de voir tous les membres et responsables du bureau de son association en temps réel.
- La **récupération d’accès (« Code oublié ? »)** permettant à un membre inscrit de retrouver le code à 6 caractères de son association à partir de son nom complet.
- L’**espace membre personnalisé** (calendrier de paiements, historique privé des reçus, choix de la couleur d’espace).
- L’**ouverture internationale** avec choix de la devise (`FCFA`, `EUR`, `USD`, `CAD`).

## Architecture & Méthode Merise

- **Présentation** : HTML5, CSS3 mobile-first et JavaScript Vanilla (sans dépendances externes, compatible hors connexion internet sur réseau local).
- **Logique applicative & API** : Serveur Node.js natif (`node:http`, `node:crypto`), contrôle d’accès par rôle (`Administrateur`, `Bureau`, `Membre`), flux temps réel SSE, validation OWASP et limitation d’essais sur les codes.
- **Base de données centralisée** : SQLite (`node:sqlite`) implémentant fidèlement le MLD normalisé :
  - `ASSOCIATION(id_assoc, nom, montant, rythme, devise, code, ...)`
  - `MEMBRE(id_membre, nom, role, couleur, #id_assoc)`
  - `COTISATION(num_recu, date, montant, operateur, statut, #id_membre)`
  - `EVENEMENT(id_event, titre, type, date, #id_assoc)`
  - `PARTICIPER(#id_membre, #id_event, reponse)`

## Lancement rapide

### Windows
Double-cliquez sur `start.bat` (ou exécutez `npm start`).

### Ligne de commande (Node.js 22.5+)
```bash
node backend/server.js
```
Puis ouvrez `http://localhost:3000` (ou l’adresse réseau affichée dans le terminal pour tester depuis un téléphone sur le même Wi-Fi).

## Scénario de démonstration (exposé en 6 étapes)

1. **Créer une association** (nom, montant facultatif, rythme, devise) → obtention du code unique à 6 caractères et du PIN Bureau.
2. **Rejoindre en tant que membre** avec ce code et un nom (ou utiliser **« Code oublié ? »** pour retrouver le code à partir du nom du membre).
3. **Payer une cotisation** (simulation Wave / Orange Money / MTN MoMo / Moov Money) → réception et impression/téléchargement du reçu horodaté.
4. **Côté bureau** : vérification du registre mis à jour en temps réel et publication d’un événement.
5. **Côté membre** : consultation de l’annuaire des **Membres** de l’association, clic sur **« Je participe »** et personnalisation de la couleur de l’espace.
6. **Test libre avec le code `DEMO`** :
   - Espace membre démo : code `DEMO` (profil par défaut *Aïcha Bamba* ou n’importe quel nouveau nom)
   - Espace bureau démo : code `DEMO`, nom `Mariam Touré`, PIN `2026`

## Tests automatisés

```bash
node --test tests/api.test.js
```
