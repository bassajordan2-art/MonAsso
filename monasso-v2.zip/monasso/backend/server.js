'use strict';

const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { URL } = require('node:url');

const { initDatabase } = require('./db');
const { RateLimiter, StreamTicketStore } = require('./security');
const { createRouter } = require('./routes');

const FRONTEND_DIR = path.resolve(__dirname, '..', 'frontend');
const MAX_JSON_BYTES = 16 * 1024;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon',
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self';",
};

function createAppServer({ dbPath } = {}) {
  const db = initDatabase(dbPath);
  const rateLimiter = new RateLimiter(6, 5 * 60 * 1000);
  const streamTickets = new StreamTicketStore(30 * 1000);
  const sseClients = new Map(); // id_assoc -> Set<res>

  function broadcastAssoc(idAssoc, reason) {
    const clients = sseClients.get(idAssoc);
    if (!clients || clients.size === 0) return;
    const payload = `event: sync\ndata: ${JSON.stringify({ reason, ts: Date.now() })}\n\n`;
    for (const clientRes of clients) {
      try {
        clientRes.write(payload);
      } catch {
        clients.delete(clientRes);
      }
    }
  }

  const { handleApi } = createRouter({
    db,
    rateLimiter,
    streamTickets,
    broadcastAssoc,
  });

  function sendJson(res, status, data) {
    const body = JSON.stringify(data);
    res.writeHead(status, {
      ...SECURITY_HEADERS,
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
    });
    res.end(body);
  }

  function sendText(res, status, text, extraHeaders = {}) {
    res.writeHead(status, {
      ...SECURITY_HEADERS,
      'Cache-Control': 'no-store',
      ...extraHeaders,
    });
    res.end(text);
  }

  function readJsonBody(req) {
    return new Promise((resolve, reject) => {
      let total = 0;
      const chunks = [];

      req.on('data', (chunk) => {
        total += chunk.length;
        if (total > MAX_JSON_BYTES) {
          reject(Object.assign(new Error('Requête trop volumineuse.'), { status: 413 }));
          req.destroy();
          return;
        }
        chunks.push(chunk);
      });

      req.on('end', () => {
        if (chunks.length === 0) {
          resolve({});
          return;
        }
        try {
          const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            reject(Object.assign(new Error('Corps JSON invalide.'), { status: 400 }));
            return;
          }
          resolve(parsed);
        } catch {
          reject(Object.assign(new Error('JSON mal formé.'), { status: 400 }));
        }
      });

      req.on('error', (err) => reject(err));
    });
  }

  function serveStatic(res, pathname) {
    let relPath = pathname === '/' ? 'index.html' : pathname === '/favicon.ico' ? 'favicon.svg' : pathname.replace(/^\/+/, '');
    const normalized = path.normalize(relPath).replace(/^(\.\.(\/|\\|$))+/, '');
    let filePath = path.resolve(FRONTEND_DIR, normalized);

    if (!filePath.startsWith(FRONTEND_DIR)) {
      sendText(res, 403, 'Accès refusé');
      return;
    }

    if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
      // Fallback SPA sur index.html uniquement pour les routes sans extension
      if (!path.extname(filePath)) {
        filePath = path.join(FRONTEND_DIR, 'index.html');
      } else {
        sendText(res, 404, 'Ressource introuvable');
        return;
      }
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    const content = fs.readFileSync(filePath);
    res.writeHead(200, {
      ...SECURITY_HEADERS,
      'Content-Type': contentType,
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
    });
    res.end(content);
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = decodeURIComponent(url.pathname);
    const clientIp = req.socket.remoteAddress || 'unknown';

    // Flux temps réel SSE (authentifié par ticket éphémère à usage unique)
    if (req.method === 'GET' && pathname === '/api/stream') {
      const ticket = url.searchParams.get('ticket');
      const ticketData = streamTickets.consume(ticket);
      if (!ticketData) {
        sendJson(res, 401, { error: 'Ticket de synchronisation invalide ou expiré.' });
        return;
      }

      res.writeHead(200, {
        ...SECURITY_HEADERS,
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      });
      res.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);

      let set = sseClients.get(ticketData.id_assoc);
      if (!set) {
        set = new Set();
        sseClients.set(ticketData.id_assoc, set);
      }
      set.add(res);

      const keepAlive = setInterval(() => {
        try {
          res.write(': ping\n\n');
        } catch {
          clearInterval(keepAlive);
        }
      }, 25000);

      req.on('close', () => {
        clearInterval(keepAlive);
        const currentSet = sseClients.get(ticketData.id_assoc);
        if (currentSet) {
          currentSet.delete(res);
          if (currentSet.size === 0) {
            sseClients.delete(ticketData.id_assoc);
          }
        }
      });
      return;
    }

    if (pathname.startsWith('/api/')) {
      try {
        await handleApi({
          req,
          res,
          pathname,
          clientIp,
          readJson: () => readJsonBody(req),
          sendJson: (status, data) => sendJson(res, status, data),
          sendText: (status, text, headers) => sendText(res, status, text, headers),
        });
      } catch (err) {
        const status = err.status || 500;
        const message = status >= 500 ? 'Erreur interne du serveur.' : err.message;
        sendJson(res, status, { error: message });
      }
      return;
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      serveStatic(res, pathname);
      return;
    }

    sendText(res, 405, 'Méthode non autorisée');
  });

  server.on('close', () => {
    for (const clients of sseClients.values()) {
      for (const clientRes of clients) {
        try {
          clientRes.end();
        } catch {
          // ignore
        }
      }
    }
    sseClients.clear();
    try {
      db.close();
    } catch {
      // ignore
    }
  });

  return { server, db };
}

function getLocalNetworkUrls(port) {
  const urls = [];
  const interfaces = os.networkInterfaces();
  for (const entries of Object.values(interfaces)) {
    if (!entries) continue;
    for (const iface of entries) {
      if (iface.family === 'IPv4' && !iface.internal) {
        urls.push(`http://${iface.address}:${port}`);
      }
    }
  }
  return urls;
}

if (require.main === module) {
  const port = Number(process.env.PORT) || 3000;
  const host = process.env.HOST || '0.0.0.0';
  const { server } = createAppServer();

  server.listen(port, host, () => {
    console.log('===================================================');
    console.log('  MonAsso — Serveur centralisé démarré');
    console.log('===================================================');
    console.log(`  Local   : http://localhost:${port}`);
    for (const lanUrl of getLocalNetworkUrls(port)) {
      console.log(`  Réseau  : ${lanUrl}  (accessible depuis téléphone)`);
    }
    console.log('  Démo    : Code DEMO  |  PIN Bureau Démo : 2026');
    console.log('===================================================');
  });
}

module.exports = {
  createAppServer,
};
