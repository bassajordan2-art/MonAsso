'use strict';

const crypto = require('node:crypto');
const {
  DEVISES,
  RYTHMES,
  OPERATEURS,
  EVENT_TYPES,
  COULEURS,
  ROLES_ALL,
  REPONSES_EVENT,
  isBureauOrAdmin,
  isAdmin,
  generateInvitationCode,
  generateReceiptNumber,
  hashPin,
  verifyPin,
  generateSessionToken,
  hashToken,
  sanitizeText,
  normalizeCode,
  validateAmount,
  validatePin,
  validateIsoDate,
} = require('./security');

const SESSION_DURATION_MS = 12 * 60 * 60 * 1000;

function safeAssociation(row) {
  if (!row) return null;
  return {
    id_assoc: row.id_assoc,
    nom: row.nom,
    montant: row.montant,
    rythme: row.rythme,
    devise: row.devise,
    code: row.code,
    created_at: row.created_at,
  };
}

function safeMember(row) {
  if (!row) return null;
  return {
    id_membre: row.id_membre,
    nom: row.nom,
    role: row.role,
    couleur: row.couleur,
    id_assoc: row.id_assoc,
    created_at: row.created_at,
  };
}

function csvCell(val) {
  const str = String(val ?? '');
  const safe = /^[=+\-@\t\r]/.test(str) ? `'${str}` : str;
  return `"${safe.replace(/"/g, '""')}"`;
}

function createRouter({ db, rateLimiter, streamTickets, broadcastAssoc }) {
  function createSession(idMembre, idAssoc) {
    const token = generateSessionToken();
    const tokenHash = hashToken(token);
    const now = Date.now();
    const createdAt = new Date(now).toISOString();
    const expiresAt = new Date(now + SESSION_DURATION_MS).toISOString();

    db.prepare('DELETE FROM APP_SESSION WHERE expires_at < ?').run(createdAt);
    db.prepare(`
      INSERT INTO APP_SESSION (token_hash, id_membre, id_assoc, created_at, expires_at)
      VALUES (?, ?, ?, ?, ?)
    `).run(tokenHash, idMembre, idAssoc, createdAt, expiresAt);

    return token;
  }

  function authenticate(req) {
    const authHeader = req.headers.authorization || '';
    if (!authHeader.startsWith('Bearer ')) return null;
    const token = authHeader.slice(7).trim();
    if (!token || token.length < 20) return null;

    const tokenHash = hashToken(token);
    const row = db.prepare(`
      SELECT s.token_hash, s.expires_at,
             m.id_membre, m.nom, m.role, m.couleur, m.id_assoc, m.created_at AS member_created_at,
             a.nom AS assoc_nom, a.montant AS assoc_montant, a.rythme AS assoc_rythme,
             a.devise AS assoc_devise, a.code AS assoc_code, a.created_at AS assoc_created_at
      FROM APP_SESSION s
      JOIN MEMBRE m ON m.id_membre = s.id_membre
      JOIN ASSOCIATION a ON a.id_assoc = s.id_assoc
      WHERE s.token_hash = ?
    `).get(tokenHash);

    if (!row) return null;
    if (Date.now() > Date.parse(row.expires_at)) {
      db.prepare('DELETE FROM APP_SESSION WHERE token_hash = ?').run(tokenHash);
      return null;
    }

    return {
      tokenHash,
      membre: {
        id_membre: row.id_membre,
        nom: row.nom,
        role: row.role,
        couleur: row.couleur,
        id_assoc: row.id_assoc,
        created_at: row.member_created_at,
      },
      association: {
        id_assoc: row.id_assoc,
        nom: row.assoc_nom,
        montant: row.assoc_montant,
        rythme: row.assoc_rythme,
        devise: row.assoc_devise,
        code: row.assoc_code,
        created_at: row.assoc_created_at,
      },
    };
  }

  function getWorkspaceData(session) {
    const { membre, association } = session;
    const isBureau = isBureauOrAdmin(membre.role);
    const isAdminFlag = isAdmin(membre.role);

    const membres = db.prepare(`
      SELECT id_membre, nom, role, couleur, created_at
      FROM MEMBRE
      WHERE id_assoc = ?
      ORDER BY
        CASE WHEN role = 'Administrateur' THEN 0
             WHEN role IN ('Président', 'Secrétaire', 'Trésorier', 'Bureau') THEN 1
             ELSE 2 END,
        nom ASC
    `).all(association.id_assoc);

    const myCotisations = db.prepare(`
      SELECT num_recu, date, montant, operateur, statut, periode, id_membre
      FROM COTISATION
      WHERE id_membre = ?
      ORDER BY date DESC
    `).all(membre.id_membre);

    const rawEvents = db.prepare(`
      SELECT id_event, titre, type, date, description, id_assoc
      FROM EVENEMENT
      WHERE id_assoc = ?
      ORDER BY date ASC
    `).all(association.id_assoc);

    const participationsStmt = db.prepare(`
      SELECT p.id_membre, p.reponse, p.updated_at, m.nom, m.role
      FROM PARTICIPER p
      JOIN MEMBRE m ON m.id_membre = p.id_membre
      WHERE p.id_event = ?
      ORDER BY m.nom ASC
    `);

    const evenements = rawEvents.map((ev) => {
      const parts = participationsStmt.all(ev.id_event);
      const confirmed = parts.filter((p) => p.reponse === 'Je participe');
      const mine = parts.find((p) => p.id_membre === membre.id_membre);

      return {
        id_event: ev.id_event,
        titre: ev.titre,
        type: ev.type,
        date: ev.date,
        description: ev.description || '',
        participantsCount: confirmed.length,
        totalResponses: parts.length,
        myResponse: mine ? mine.reponse : null,
        participants: isBureau
          ? parts.map((p) => ({
              id_membre: p.id_membre,
              nom: p.nom,
              role: p.role,
              reponse: p.reponse,
            }))
          : undefined,
      };
    });

    let registry = null;
    if (isBureau) {
      const allMembers = db.prepare(`
        SELECT m.id_membre, m.nom, m.role, m.couleur, m.created_at,
               COALESCE(SUM(c.montant), 0) AS total_verse,
               COUNT(c.num_recu) AS nb_cotisations,
               MAX(c.date) AS dernier_paiement
        FROM MEMBRE m
        LEFT JOIN COTISATION c ON c.id_membre = m.id_membre AND c.statut = 'Validée'
        WHERE m.id_assoc = ?
        GROUP BY m.id_membre
        ORDER BY
          CASE WHEN m.role = 'Administrateur' THEN 0
               WHEN m.role IN ('Président', 'Secrétaire', 'Trésorier', 'Bureau') THEN 1
               ELSE 2 END,
          m.nom ASC
      `).all(association.id_assoc);

      const allCotisations = db.prepare(`
        SELECT c.num_recu, c.date, c.montant, c.operateur, c.statut, c.periode,
               c.id_membre, m.nom AS membre_nom, m.role AS membre_role
        FROM COTISATION c
        JOIN MEMBRE m ON m.id_membre = c.id_membre
        WHERE m.id_assoc = ?
        ORDER BY c.date DESC
      `).all(association.id_assoc);

      const byOperator = {};
      let totalCaisse = 0;
      for (const op of OPERATEURS) {
        byOperator[op] = 0;
      }
      for (const c of allCotisations) {
        if (c.statut === 'Validée') {
          totalCaisse += Number(c.montant);
          byOperator[c.operateur] = (byOperator[c.operateur] || 0) + Number(c.montant);
        }
      }

      const payingMembersCount = allMembers.filter((m) => Number(m.nb_cotisations) > 0).length;

      registry = {
        membres: allMembers,
        cotisations: allCotisations,
        stats: {
          totalCaisse: Math.round(totalCaisse * 100) / 100,
          totalTransactions: allCotisations.length,
          payingMembersCount,
          totalMembersCount: allMembers.length,
          byOperator,
        },
      };
    }

    return {
      association,
      membre,
      permissions: {
        isBureau,
        isAdmin: isAdminFlag,
      },
      membres,
      myCotisations,
      evenements,
      registry,
    };
  }

  async function handleApi({ req, res, pathname, clientIp, readJson, sendJson, sendText }) {
    if (req.method === 'GET' && pathname === '/api/health') {
      return sendJson(200, {
        ok: true,
        mode: 'centralized-sqlite',
        serverTime: new Date().toISOString(),
      });
    }

    if (req.method === 'POST' && pathname === '/api/associations') {
      const body = await readJson();
      const nom = sanitizeText(body.nom, 2, 100);
      const fondateurNom = sanitizeText(body.fondateurNom, 2, 80);
      const rythme = RYTHMES.includes(body.rythme) ? body.rythme : null;
      const devise = DEVISES.includes(body.devise) ? body.devise : null;
      const montant = validateAmount(body.montant, { optional: true });
      const rawPin = body.pinBureau ? validatePin(body.pinBureau) : String(crypto.randomInt(1000, 9999));

      if (!nom) {
        return sendJson(400, { error: 'Le nom de l’association doit contenir entre 2 et 100 caractères.' });
      }
      if (!fondateurNom) {
        return sendJson(400, { error: 'Votre nom (fondateur) doit contenir entre 2 et 80 caractères.' });
      }
      if (!rythme) {
        return sendJson(400, { error: 'Rythme de cotisation invalide.' });
      }
      if (!devise) {
        return sendJson(400, { error: 'Devise non prise en charge.' });
      }
      if (Number.isNaN(montant)) {
        return sendJson(400, { error: 'Le montant doit être positif ou laissé facultatif.' });
      }
      if (!rawPin) {
        return sendJson(400, { error: 'Le code PIN Bureau doit contenir entre 4 et 6 chiffres.' });
      }

      const existsCodeStmt = db.prepare('SELECT 1 FROM ASSOCIATION WHERE code = ?');
      const code = generateInvitationCode((candidate) => Boolean(existsCodeStmt.get(candidate)));
      const nowIso = new Date().toISOString();
      const pinHash = hashPin(rawPin);

      const assocRes = db.prepare(`
        INSERT INTO ASSOCIATION (nom, montant, rythme, devise, code, pin_bureau_hash, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(nom, montant, rythme, devise, code, pinHash, nowIso);
      const idAssoc = Number(assocRes.lastInsertRowid);

      const memberRes = db.prepare(`
        INSERT INTO MEMBRE (nom, role, couleur, id_assoc, created_at)
        VALUES (?, 'Administrateur', 'emeraude', ?, ?)
      `).run(fondateurNom, idAssoc, nowIso);
      const idMembre = Number(memberRes.lastInsertRowid);

      const association = safeAssociation(
        db.prepare('SELECT * FROM ASSOCIATION WHERE id_assoc = ?').get(idAssoc)
      );
      const membre = safeMember(
        db.prepare('SELECT * FROM MEMBRE WHERE id_membre = ?').get(idMembre)
      );

      const token = createSession(idMembre, idAssoc);
      return sendJson(201, {
        token,
        association,
        membre,
        pinBureau: rawPin,
        permissions: { isBureau: true, isAdmin: true },
      });
    }

    if (req.method === 'POST' && pathname === '/api/associations/join') {
      const rateCheck = rateLimiter.check(clientIp);
      if (!rateCheck.allowed) {
        return sendJson(429, {
          error: `Trop de tentatives incorrectes. Veuillez réessayer dans ${rateCheck.retryAfterSeconds} secondes.`,
          retryAfterSeconds: rateCheck.retryAfterSeconds,
        });
      }

      const body = await readJson();
      const code = normalizeCode(body.code);
      if (!code) {
        rateLimiter.recordFailure(clientIp);
        return sendJson(400, {
          error: 'Le code doit contenir exactement 6 caractères (lettres majuscules et chiffres) ou DEMO.',
        });
      }

      const assoc = db.prepare('SELECT * FROM ASSOCIATION WHERE code = ?').get(code);
      if (!assoc) {
        rateLimiter.recordFailure(clientIp);
        return sendJson(404, {
          error: 'Code d’invitation introuvable. Vérifiez les 6 caractères auprès du bureau de votre association.',
        });
      }

      let nom = sanitizeText(body.nom, 2, 80);
      if (code === 'DEMO' && (!body.nom || String(body.nom).trim() === '')) {
        nom = 'Aïcha Bamba';
      }
      if (!nom) {
        return sendJson(400, {
          error: 'Veuillez saisir votre nom complet (entre 2 et 80 caractères).',
        });
      }

      const existingMember = db.prepare(`
        SELECT * FROM MEMBRE
        WHERE id_assoc = ? AND LOWER(TRIM(nom)) = LOWER(TRIM(?))
      `).get(assoc.id_assoc, nom);

      let membre = existingMember;
      let joinedNew = false;

      if (existingMember) {
        if (isBureauOrAdmin(existingMember.role)) {
          const pin = body.pinBureau ? String(body.pinBureau).trim() : '';
          if (!pin) {
            return sendJson(401, {
              requiresPin: true,
              error: 'Ce nom correspond à un membre du bureau. Saisissez le code PIN Bureau pour vous connecter.',
            });
          }
          if (!verifyPin(pin, assoc.pin_bureau_hash)) {
            rateLimiter.recordFailure(clientIp);
            return sendJson(401, {
              requiresPin: true,
              error: 'Code PIN Bureau incorrect.',
            });
          }
        }
      } else {
        const nowIso = new Date().toISOString();
        const insertRes = db.prepare(`
          INSERT INTO MEMBRE (nom, role, couleur, id_assoc, created_at)
          VALUES (?, 'Membre', 'emeraude', ?, ?)
        `).run(nom, assoc.id_assoc, nowIso);
        membre = db.prepare('SELECT * FROM MEMBRE WHERE id_membre = ?').get(Number(insertRes.lastInsertRowid));
        joinedNew = true;
      }

      rateLimiter.reset(clientIp);
      const token = createSession(membre.id_membre, assoc.id_assoc);

      if (joinedNew) {
        broadcastAssoc(assoc.id_assoc, 'member_joined');
      }

      return sendJson(200, {
        token,
        association: safeAssociation(assoc),
        membre: safeMember(membre),
        joinedNew,
        permissions: {
          isBureau: isBureauOrAdmin(membre.role),
          isAdmin: isAdmin(membre.role),
        },
      });
    }

    if (req.method === 'POST' && pathname === '/api/associations/recover-code') {
      const rateCheck = rateLimiter.check(clientIp);
      if (!rateCheck.allowed) {
        return sendJson(429, {
          error: `Trop de tentatives. Veuillez réessayer dans ${rateCheck.retryAfterSeconds} secondes.`,
          retryAfterSeconds: rateCheck.retryAfterSeconds,
        });
      }

      const body = await readJson();
      const nom = sanitizeText(body.nom, 2, 80);
      if (!nom) {
        return sendJson(400, {
          error: 'Veuillez saisir votre nom complet (entre 2 et 80 caractères).',
        });
      }

      const assocNom = body.assocNom ? sanitizeText(body.assocNom, 2, 100) : null;
      if (body.assocNom && String(body.assocNom).trim() !== '' && !assocNom) {
        return sendJson(400, {
          error: 'Le nom de l’association doit contenir entre 2 et 100 caractères.',
        });
      }

      let rows;
      if (assocNom) {
        rows = db.prepare(`
          SELECT m.id_membre, m.nom AS membre_nom, m.role,
                 a.id_assoc, a.nom AS nom_association, a.rythme, a.devise, a.code
          FROM MEMBRE m
          JOIN ASSOCIATION a ON a.id_assoc = m.id_assoc
          WHERE LOWER(TRIM(m.nom)) = LOWER(TRIM(?))
            AND LOWER(a.nom) LIKE ?
          ORDER BY a.created_at DESC
        `).all(nom, `%${assocNom.toLowerCase()}%`);
      } else {
        rows = db.prepare(`
          SELECT m.id_membre, m.nom AS membre_nom, m.role,
                 a.id_assoc, a.nom AS nom_association, a.rythme, a.devise, a.code
          FROM MEMBRE m
          JOIN ASSOCIATION a ON a.id_assoc = m.id_assoc
          WHERE LOWER(TRIM(m.nom)) = LOWER(TRIM(?))
          ORDER BY a.created_at DESC
        `).all(nom);
      }

      if (!rows || rows.length === 0) {
        rateLimiter.recordFailure(clientIp);
        return sendJson(404, {
          error: 'Aucune association trouvée pour ce nom. Vérifiez l’orthographe exacte utilisée lors de votre inscription.',
        });
      }

      rateLimiter.reset(clientIp);
      return sendJson(200, {
        matches: rows.map((r) => ({
          id_assoc: r.id_assoc,
          nom_association: r.nom_association,
          rythme: r.rythme,
          devise: r.devise,
          code: r.code,
          membre_nom: r.membre_nom,
          role: r.role,
          requiresPin: isBureauOrAdmin(r.role),
        })),
      });
    }

    const session = authenticate(req);
    if (!session) {
      return sendJson(401, { error: 'Session expirée ou non authentifiée.' });
    }

    if (req.method === 'POST' && pathname === '/api/auth/logout') {
      db.prepare('DELETE FROM APP_SESSION WHERE token_hash = ?').run(session.tokenHash);
      return sendJson(200, { ok: true });
    }

    if (req.method === 'POST' && pathname === '/api/auth/stream-ticket') {
      const ticket = streamTickets.issue({
        id_assoc: session.association.id_assoc,
        id_membre: session.membre.id_membre,
      });
      return sendJson(200, { ticket });
    }

    if (req.method === 'GET' && pathname === '/api/workspace') {
      return sendJson(200, getWorkspaceData(session));
    }

    if (req.method === 'POST' && pathname === '/api/cotisations') {
      const body = await readJson();
      const operateur = OPERATEURS.includes(body.operateur) ? body.operateur : null;
      const montant = validateAmount(body.montant, { optional: false });
      const periode = body.periode ? sanitizeText(body.periode, 1, 60) : null;

      if (!operateur) {
        return sendJson(400, { error: 'Opérateur Mobile Money non reconnu.' });
      }
      if (Number.isNaN(montant)) {
        return sendJson(400, { error: 'Veuillez indiquer un montant de cotisation valide.' });
      }

      const existsReceiptStmt = db.prepare('SELECT 1 FROM COTISATION WHERE num_recu = ?');
      const numRecu = generateReceiptNumber((candidate) => Boolean(existsReceiptStmt.get(candidate)));
      const nowIso = new Date().toISOString();

      db.prepare(`
        INSERT INTO COTISATION (num_recu, date, montant, operateur, statut, periode, id_membre)
        VALUES (?, ?, ?, ?, 'Validée', ?, ?)
      `).run(numRecu, nowIso, montant, operateur, periode, session.membre.id_membre);

      const cotisation = db.prepare('SELECT * FROM COTISATION WHERE num_recu = ?').get(numRecu);
      broadcastAssoc(session.association.id_assoc, 'cotisation_created');

      return sendJson(201, {
        cotisation,
        membre: session.membre,
        association: session.association,
      });
    }

    if (req.method === 'PATCH' && pathname === '/api/membres/me/couleur') {
      const body = await readJson();
      const couleur = COULEURS.includes(body.couleur) ? body.couleur : null;
      if (!couleur) {
        return sendJson(400, { error: 'Thème de couleur non reconnu.' });
      }

      db.prepare('UPDATE MEMBRE SET couleur = ? WHERE id_membre = ?').run(couleur, session.membre.id_membre);
      const updated = safeMember(
        db.prepare('SELECT * FROM MEMBRE WHERE id_membre = ?').get(session.membre.id_membre)
      );
      broadcastAssoc(session.association.id_assoc, 'member_updated');
      return sendJson(200, { membre: updated });
    }

    if (req.method === 'POST' && pathname === '/api/evenements') {
      if (!isBureauOrAdmin(session.membre.role)) {
        return sendJson(403, { error: 'Action réservée aux membres du bureau et à l’administrateur.' });
      }

      const body = await readJson();
      const titre = sanitizeText(body.titre, 3, 120);
      const type = EVENT_TYPES.includes(body.type) ? body.type : null;
      const date = validateIsoDate(body.date);
      const description = body.description ? sanitizeText(body.description, 1, 400) : '';

      if (!titre) {
        return sendJson(400, { error: 'Le titre de l’événement doit contenir entre 3 et 120 caractères.' });
      }
      if (!type) {
        return sendJson(400, { error: 'Type d’événement invalide (Réunion, Activité ou Assemblée générale).' });
      }
      if (!date) {
        return sendJson(400, { error: 'Date d’événement invalide.' });
      }

      const evRes = db.prepare(`
        INSERT INTO EVENEMENT (titre, type, date, description, id_assoc)
        VALUES (?, ?, ?, ?, ?)
      `).run(titre, type, date, description || '', session.association.id_assoc);

      const evenement = db.prepare('SELECT * FROM EVENEMENT WHERE id_event = ?').get(Number(evRes.lastInsertRowid));
      broadcastAssoc(session.association.id_assoc, 'event_created');
      return sendJson(201, { evenement });
    }

    const participateMatch = pathname.match(/^\/api\/evenements\/(\d+)\/participer$/);
    if (req.method === 'POST' && participateMatch) {
      const idEvent = Number(participateMatch[1]);
      const ev = db.prepare('SELECT * FROM EVENEMENT WHERE id_event = ? AND id_assoc = ?')
        .get(idEvent, session.association.id_assoc);
      if (!ev) {
        return sendJson(404, { error: 'Événement introuvable dans votre association.' });
      }

      const body = await readJson();
      const reponse = REPONSES_EVENT.includes(body.reponse) ? body.reponse : 'Je participe';
      const nowIso = new Date().toISOString();

      db.prepare(`
        INSERT INTO PARTICIPER (id_membre, id_event, reponse, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(id_membre, id_event)
        DO UPDATE SET reponse = excluded.reponse, updated_at = excluded.updated_at
      `).run(session.membre.id_membre, idEvent, reponse, nowIso);

      broadcastAssoc(session.association.id_assoc, 'participation_updated');
      return sendJson(200, { id_event: idEvent, reponse });
    }

    const roleMatch = pathname.match(/^\/api\/membres\/(\d+)\/role$/);
    if (req.method === 'PATCH' && roleMatch) {
      if (!isAdmin(session.membre.role)) {
        return sendJson(403, { error: 'Seul l’administrateur (fondateur) peut modifier les rôles.' });
      }

      const targetId = Number(roleMatch[1]);
      const target = db.prepare('SELECT * FROM MEMBRE WHERE id_membre = ? AND id_assoc = ?')
        .get(targetId, session.association.id_assoc);
      if (!target) {
        return sendJson(404, { error: 'Membre introuvable dans cette association.' });
      }

      const body = await readJson();
      const role = ROLES_ALL.includes(body.role) ? body.role : null;
      if (!role) {
        return sendJson(400, { error: 'Rôle invalide.' });
      }

      if (target.role === 'Administrateur' && role !== 'Administrateur') {
        const admins = db.prepare(`
          SELECT COUNT(*) AS cnt FROM MEMBRE
          WHERE id_assoc = ? AND role = 'Administrateur'
        `).get(session.association.id_assoc);
        if (Number(admins.cnt) <= 1) {
          return sendJson(400, { error: 'L’association doit conserver au moins un administrateur.' });
        }
      }

      db.prepare('UPDATE MEMBRE SET role = ? WHERE id_membre = ?').run(role, targetId);
      broadcastAssoc(session.association.id_assoc, 'member_updated');
      return sendJson(200, {
        membre: safeMember(db.prepare('SELECT * FROM MEMBRE WHERE id_membre = ?').get(targetId)),
      });
    }

    if (req.method === 'GET' && pathname === '/api/registry/export') {
      if (!isBureauOrAdmin(session.membre.role)) {
        return sendJson(403, { error: 'Export réservé aux membres du bureau.' });
      }

      const rows = db.prepare(`
        SELECT c.num_recu, c.date, m.nom AS membre_nom, m.role AS membre_role,
               c.operateur, c.periode, c.montant, c.statut
        FROM COTISATION c
        JOIN MEMBRE m ON m.id_membre = c.id_membre
        WHERE m.id_assoc = ?
        ORDER BY c.date DESC
      `).all(session.association.id_assoc);

      const header = ['N° Reçu', 'Date', 'Membre', 'Rôle', 'Opérateur', 'Période', 'Montant', 'Devise', 'Statut'];
      const lines = [header.map(csvCell).join(';')];
      for (const r of rows) {
        lines.push([
          r.num_recu,
          r.date,
          r.membre_nom,
          r.membre_role,
          r.operateur,
          r.periode || '',
          r.montant,
          session.association.devise,
          r.statut,
        ].map(csvCell).join(';'));
      }

      const bom = '\uFEFF';
      const filename = `registre-${session.association.code.toLowerCase()}.csv`;
      return sendText(200, bom + lines.join('\r\n'), {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
      });
    }

    return sendJson(404, { error: 'Point de terminaison API introuvable.' });
  }

  return { handleApi };
}

module.exports = {
  createRouter,
};
