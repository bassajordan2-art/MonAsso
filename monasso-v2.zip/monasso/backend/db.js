'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { hashPin } = require('./security');

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'monasso.db');

function initDatabase(dbPath = DB_PATH) {
  if (dbPath !== ':memory:') {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  }

  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA journal_mode = WAL;');

  // Modèle Physique de Données (MPD) issu du MLD Merise :
  // ASSOCIATION, MEMBRE, COTISATION, EVENEMENT, PARTICIPER + table technique de session
  db.exec(`
    CREATE TABLE IF NOT EXISTS ASSOCIATION (
      id_assoc INTEGER PRIMARY KEY AUTOINCREMENT,
      nom TEXT NOT NULL,
      montant REAL,
      rythme TEXT NOT NULL,
      devise TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      pin_bureau_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_association_code ON ASSOCIATION(code);

    CREATE TABLE IF NOT EXISTS MEMBRE (
      id_membre INTEGER PRIMARY KEY AUTOINCREMENT,
      nom TEXT NOT NULL,
      role TEXT NOT NULL,
      couleur TEXT NOT NULL DEFAULT 'emeraude',
      id_assoc INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (id_assoc) REFERENCES ASSOCIATION(id_assoc) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_membre_assoc ON MEMBRE(id_assoc);

    CREATE TABLE IF NOT EXISTS COTISATION (
      num_recu TEXT PRIMARY KEY,
      date TEXT NOT NULL,
      montant REAL NOT NULL,
      operateur TEXT NOT NULL,
      statut TEXT NOT NULL,
      periode TEXT,
      id_membre INTEGER NOT NULL,
      FOREIGN KEY (id_membre) REFERENCES MEMBRE(id_membre) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_cotisation_membre ON COTISATION(id_membre);

    CREATE TABLE IF NOT EXISTS EVENEMENT (
      id_event INTEGER PRIMARY KEY AUTOINCREMENT,
      titre TEXT NOT NULL,
      type TEXT NOT NULL,
      date TEXT NOT NULL,
      description TEXT,
      id_assoc INTEGER NOT NULL,
      FOREIGN KEY (id_assoc) REFERENCES ASSOCIATION(id_assoc) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_evenement_assoc ON EVENEMENT(id_assoc);

    CREATE TABLE IF NOT EXISTS PARTICIPER (
      id_membre INTEGER NOT NULL,
      id_event INTEGER NOT NULL,
      reponse TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      PRIMARY KEY (id_membre, id_event),
      FOREIGN KEY (id_membre) REFERENCES MEMBRE(id_membre) ON DELETE CASCADE,
      FOREIGN KEY (id_event) REFERENCES EVENEMENT(id_event) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS APP_SESSION (
      token_hash TEXT PRIMARY KEY,
      id_membre INTEGER NOT NULL,
      id_assoc INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      FOREIGN KEY (id_membre) REFERENCES MEMBRE(id_membre) ON DELETE CASCADE,
      FOREIGN KEY (id_assoc) REFERENCES ASSOCIATION(id_assoc) ON DELETE CASCADE
    );
  `);

  seedDemoAssociation(db);
  return db;
}

function addDaysIso(daysOffset, hour = 10, minute = 0) {
  const dt = new Date();
  dt.setUTCDate(dt.getUTCDate() + daysOffset);
  dt.setUTCHours(hour, minute, 0, 0);
  return dt.toISOString();
}

function seedDemoAssociation(db) {
  const existing = db.prepare('SELECT id_assoc FROM ASSOCIATION WHERE code = ?').get('DEMO');
  if (existing) return;

  const nowIso = new Date().toISOString();
  const pinHash = hashPin('2026');

  const insertAssoc = db.prepare(`
    INSERT INTO ASSOCIATION (nom, montant, rythme, devise, code, pin_bureau_hash, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const assocRes = insertAssoc.run(
    'Amicale Fraternité Cocody',
    10000,
    'Mensuel',
    'FCFA',
    'DEMO',
    pinHash,
    nowIso
  );
  const idAssoc = Number(assocRes.lastInsertRowid);

  const insertMember = db.prepare(`
    INSERT INTO MEMBRE (nom, role, couleur, id_assoc, created_at)
    VALUES (?, ?, ?, ?, ?)
  `);

  const members = [
    { nom: 'Kouadio Konan', role: 'Administrateur', couleur: 'emeraude' },
    { nom: 'Mariam Touré', role: 'Trésorier', couleur: 'lagune' },
    { nom: 'Fatoumata Diallo', role: 'Secrétaire', couleur: 'prune' },
    { nom: 'Aïcha Bamba', role: 'Membre', couleur: 'emeraude' },
    { nom: 'Jean-Luc Koffi', role: 'Membre', couleur: 'terracotta' },
    { nom: 'Moussa Coulibaly', role: 'Membre', couleur: 'or' },
  ];

  const memberIds = {};
  for (const m of members) {
    const r = insertMember.run(m.nom, m.role, m.couleur, idAssoc, nowIso);
    memberIds[m.nom] = Number(r.lastInsertRowid);
  }

  const insertCotisation = db.prepare(`
    INSERT INTO COTISATION (num_recu, date, montant, operateur, statut, periode, id_membre)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const cotisations = [
    ['REC-20260905-104201', addDaysIso(-60, 14, 15), 10000, 'Wave', 'Validée', 'Septembre 2026', memberIds['Aïcha Bamba']],
    ['REC-20261005-204819', addDaysIso(-30, 9, 42), 10000, 'Orange Money', 'Validée', 'Octobre 2026', memberIds['Aïcha Bamba']],
    ['REC-20261006-311044', addDaysIso(-29, 17, 20), 10000, 'MTN MoMo', 'Validée', 'Octobre 2026', memberIds['Jean-Luc Koffi']],
    ['REC-20261108-452018', addDaysIso(-18, 11, 5), 10000, 'Wave', 'Validée', 'Novembre 2026', memberIds['Kouadio Konan']],
    ['REC-20261109-590133', addDaysIso(-17, 15, 30), 10000, 'Orange Money', 'Validée', 'Novembre 2026', memberIds['Mariam Touré']],
    ['REC-20261112-674329', addDaysIso(-14, 19, 12), 10000, 'Wave', 'Validée', 'Novembre 2026', memberIds['Fatoumata Diallo']],
    ['REC-20261115-781490', addDaysIso(-10, 8, 50), 10000, 'MTN MoMo', 'Validée', 'Novembre 2026', memberIds['Moussa Coulibaly']],
  ];

  for (const row of cotisations) {
    insertCotisation.run(...row);
  }

  const insertEvent = db.prepare(`
    INSERT INTO EVENEMENT (titre, type, date, description, id_assoc)
    VALUES (?, ?, ?, ?, ?)
  `);

  const ev1 = Number(
    insertEvent.run(
      'Réunion mensuelle de suivi des cotisations',
      'Réunion',
      addDaysIso(4, 18, 0),
      'Point sur la caisse du mois, préparation du prochain tour de tontine et questions diverses.',
      idAssoc
    ).lastInsertRowid
  );
  const ev2 = Number(
    insertEvent.run(
      'Journée d’entraide et remise de fonds',
      'Activité',
      addDaysIso(12, 10, 0),
      'Rencontre conviviale des membres au foyer de Cocody.',
      idAssoc
    ).lastInsertRowid
  );
  const ev3 = Number(
    insertEvent.run(
      'Assemblée générale annuelle 2026-2027',
      'Assemblée générale',
      addDaysIso(24, 9, 30),
      'Bilan financier annuel, vote des résolutions et calendrier de l’exercice suivant.',
      idAssoc
    ).lastInsertRowid
  );

  const insertParticiper = db.prepare(`
    INSERT INTO PARTICIPER (id_membre, id_event, reponse, updated_at)
    VALUES (?, ?, ?, ?)
  `);

  insertParticiper.run(memberIds['Kouadio Konan'], ev1, 'Je participe', nowIso);
  insertParticiper.run(memberIds['Mariam Touré'], ev1, 'Je participe', nowIso);
  insertParticiper.run(memberIds['Fatoumata Diallo'], ev1, 'Je participe', nowIso);
  insertParticiper.run(memberIds['Jean-Luc Koffi'], ev1, 'Je participe', nowIso);

  insertParticiper.run(memberIds['Kouadio Konan'], ev2, 'Je participe', nowIso);
  insertParticiper.run(memberIds['Moussa Coulibaly'], ev2, 'Je participe', nowIso);

  insertParticiper.run(memberIds['Kouadio Konan'], ev3, 'Je participe', nowIso);
  insertParticiper.run(memberIds['Mariam Touré'], ev3, 'Je participe', nowIso);
  insertParticiper.run(memberIds['Aïcha Bamba'], ev3, 'Je participe', nowIso);
}

module.exports = {
  initDatabase,
  DB_PATH,
};
