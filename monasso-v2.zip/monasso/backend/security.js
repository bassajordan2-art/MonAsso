'use strict';

const crypto = require('node:crypto');

// Alphabet de 36 symboles (A-Z et 0-9) => 36^6 = 2 176 782 336 combinaisons
const CODE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
const CODE_LENGTH = 6;

const DEVISES = ['FCFA', 'EUR', 'USD', 'CAD'];
const RYTHMES = ['Hebdomadaire', 'Bimensuel', 'Mensuel', 'Trimestriel', 'Annuel', 'Ponctuel'];
const OPERATEURS = ['Wave', 'Orange Money', 'MTN MoMo', 'Moov Money'];
const EVENT_TYPES = ['Réunion', 'Activité', 'Assemblée générale'];
const COULEURS = ['emeraude', 'lagune', 'terracotta', 'or', 'prune', 'ardoise'];
const ROLES_BUREAU = ['Administrateur', 'Président', 'Secrétaire', 'Trésorier', 'Bureau'];
const ROLES_ALL = [...ROLES_BUREAU, 'Membre'];
const REPONSES_EVENT = ['Je participe', 'Indisponible'];

function isBureauOrAdmin(role) {
  return ROLES_BUREAU.includes(role);
}

function isAdmin(role) {
  return role === 'Administrateur';
}

function generateInvitationCode(existsFn) {
  for (let attempt = 0; attempt < 25; attempt += 1) {
    let code = '';
    for (let i = 0; i < CODE_LENGTH; i += 1) {
      code += CODE_ALPHABET[crypto.randomInt(0, CODE_ALPHABET.length)];
    }
    if (code !== 'DEMO' && !existsFn(code)) {
      return code;
    }
  }
  throw new Error('Impossible de générer un code unique.');
}

function generateReceiptNumber(existsFn) {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = String(now.getUTCMonth() + 1).padStart(2, '0');
  const d = String(now.getUTCDate()).padStart(2, '0');
  for (let attempt = 0; attempt < 25; attempt += 1) {
    const suffix = String(crypto.randomInt(100000, 999999));
    const numRecu = `REC-${y}${m}${d}-${suffix}`;
    if (!existsFn(numRecu)) {
      return numRecu;
    }
  }
  throw new Error('Impossible de générer un numéro de reçu unique.');
}

function hashPin(pin) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(String(pin), salt, 32).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPin(pin, storedHash) {
  if (!pin || !storedHash || typeof storedHash !== 'string') return false;
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, originalHex] = parts;
  const derived = crypto.scryptSync(String(pin), salt, 32);
  const original = Buffer.from(originalHex, 'hex');
  if (derived.length !== original.length) return false;
  return crypto.timingSafeEqual(derived, original);
}

function generateSessionToken() {
  return crypto.randomBytes(32).toString('hex');
}

function hashToken(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}

// Limitation du nombre d'essais (protection anti-force brute sur les codes et PIN)
class RateLimiter {
  constructor(maxAttempts = 6, windowMs = 5 * 60 * 1000) {
    this.maxAttempts = maxAttempts;
    this.windowMs = windowMs;
    this.buckets = new Map();
  }

  _prune(key, now) {
    const timestamps = this.buckets.get(key) || [];
    const recent = timestamps.filter((t) => now - t < this.windowMs);
    if (recent.length === 0) {
      this.buckets.delete(key);
    } else {
      this.buckets.set(key, recent);
    }
    return recent;
  }

  check(key) {
    const now = Date.now();
    const recent = this._prune(key, now);
    if (recent.length >= this.maxAttempts) {
      const oldest = recent[0];
      const retryAfterSeconds = Math.max(1, Math.ceil((this.windowMs - (now - oldest)) / 1000));
      return { allowed: false, retryAfterSeconds };
    }
    return { allowed: true, retryAfterSeconds: 0 };
  }

  recordFailure(key) {
    const now = Date.now();
    const recent = this._prune(key, now);
    recent.push(now);
    this.buckets.set(key, recent);
  }

  reset(key) {
    this.buckets.delete(key);
  }
}

// Tickets éphémères (30s, usage unique) pour authentifier les flux SSE sans exposer le token de session dans l'URL
class StreamTicketStore {
  constructor(ttlMs = 30 * 1000) {
    this.ttlMs = ttlMs;
    this.tickets = new Map();
  }

  issue(sessionPayload) {
    const ticket = crypto.randomBytes(24).toString('hex');
    this.tickets.set(ticket, {
      ...sessionPayload,
      expiresAt: Date.now() + this.ttlMs,
    });
    if (this.tickets.size > 1000) {
      const now = Date.now();
      for (const [k, v] of this.tickets.entries()) {
        if (v.expiresAt <= now) this.tickets.delete(k);
      }
    }
    return ticket;
  }

  consume(ticket) {
    if (!ticket || typeof ticket !== 'string') return null;
    const entry = this.tickets.get(ticket);
    if (!entry) return null;
    this.tickets.delete(ticket);
    if (Date.now() > entry.expiresAt) return null;
    return entry;
  }
}

// Validation stricte des saisies (OWASP)
function sanitizeText(value, minLen = 1, maxLen = 100) {
  if (typeof value !== 'string') return null;
  // Supprime les caractères de contrôle ASCII
  const cleaned = value.replace(/[\u0000-\u001F\u007F]/g, '').replace(/\s+/g, ' ').trim();
  if (cleaned.length < minLen || cleaned.length > maxLen) return null;
  return cleaned;
}

function normalizeCode(value) {
  if (typeof value !== 'string') return null;
  const cleaned = value.trim().toUpperCase();
  if (cleaned === 'DEMO') return 'DEMO';
  if (/^[A-Z0-9]{6}$/.test(cleaned)) return cleaned;
  return null;
}

function validateAmount(value, { optional = false } = {}) {
  if (value === null || value === undefined || value === '') {
    return optional ? null : NaN;
  }
  const num = Number(value);
  if (!Number.isFinite(num) || num <= 0 || num > 100000000) {
    return NaN;
  }
  return Math.round(num * 100) / 100;
}

function validatePin(value) {
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  const str = String(value).trim();
  if (!/^\d{4,6}$/.test(str)) return null;
  return str;
}

function validateIsoDate(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) return null;
  // Garde une borne raisonnable (entre 2020 et 2050)
  const year = parsed.getUTCFullYear();
  if (year < 2020 || year > 2050) return null;
  return parsed.toISOString();
}

module.exports = {
  DEVISES,
  RYTHMES,
  OPERATEURS,
  EVENT_TYPES,
  COULEURS,
  ROLES_BUREAU,
  ROLES_ALL,
  REPONSES_EVENT,
  isBureauOrAdmin,
  isAdmin,
  generateInvitationCode,
  generateReceiptNumber,
  hashPin,
  verifyPin,
  generateSessionToken,
  hashToken,
  RateLimiter,
  StreamTicketStore,
  sanitizeText,
  normalizeCode,
  validateAmount,
  validatePin,
  validateIsoDate,
};
